package com.example.zombieevolution.block;

import com.example.zombieevolution.ZombieEvolution;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1814;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public class ModBlocks {
    public static final class_2248 STRUCTURE_FOUNDATION = new StructureFoundationBlock(
            class_4970.class_2251.method_9630(class_2246.field_10340)
                    .method_9629(-1.0f, 3600000.0f)
                    .method_42327()
    );

    public static void register() {
        class_2378.method_10230(class_7923.field_41175, ZombieEvolution.id("structure_foundation"), STRUCTURE_FOUNDATION);
        class_2378.method_10230(class_7923.field_41178, ZombieEvolution.id("structure_foundation"),
                new class_1747(STRUCTURE_FOUNDATION, new FabricItemSettings().method_7894(class_1814.field_8904)));

        ItemGroupEvents.modifyEntriesEvent(net.minecraft.class_7706.field_40195)
                .register(entries -> entries.method_45421(STRUCTURE_FOUNDATION));
    }
}
