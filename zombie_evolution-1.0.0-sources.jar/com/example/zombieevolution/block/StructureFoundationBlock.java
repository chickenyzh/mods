package com.example.zombieevolution.block;

import com.example.zombieevolution.StructureManager;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_4970;

public class StructureFoundationBlock extends class_2248 {

    private static int buildingCounter = 0;

    public StructureFoundationBlock(class_4970.class_2251 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        showScanRange(world, pos);

        if (!world.field_9236) {
            buildingCounter++;
            String name = "building_" + buildingCounter;
            String filePath = StructureManager.saveStructure(world, pos, name);

            if (filePath != null) {
                long fileSize = new java.io.File(filePath).length();
                player.method_7353(class_2561.method_43470("§a✔ 建筑已保存 §7(" + (fileSize / 1024 + 1) + "KB)"), false);
                player.method_7353(class_2561.method_43470("§e文件名: " + name + ".json"), false);
                player.method_7353(class_2561.method_43470("§7📁 " + filePath), false);
            } else {
                player.method_7353(class_2561.method_43470("§c✘ 上方没有检测到方块！请先搭建建筑"), false);
            }
        }

        return class_1269.field_5812;
    }

    private void showScanRange(class_1937 world, class_2338 pos) {
        class_2338 start = pos.method_10084();
        int w = 16, h = 16, d = 16;

        class_2338[] corners = new class_2338[8];
        corners[0] = start;
        corners[1] = start.method_10069(w - 1, 0, 0);
        corners[2] = start.method_10069(0, 0, d - 1);
        corners[3] = start.method_10069(w - 1, 0, d - 1);
        corners[4] = start.method_10069(0, h - 1, 0);
        corners[5] = start.method_10069(w - 1, h - 1, 0);
        corners[6] = start.method_10069(0, h - 1, d - 1);
        corners[7] = start.method_10069(w - 1, h - 1, d - 1);

        // Vertical edges
        for (int i = 0; i < 4; i++) {
            class_2338 bottom = corners[i];
            class_2338 top = corners[i + 4];
            int yStep = Math.max(1, h / 8);
            for (int y = 0; y < h; y += yStep) {
                spawnParticle(world, bottom.method_10263(), bottom.method_10264() + y, bottom.method_10260());
            }
            spawnParticle(world, top.method_10263(), top.method_10264(), top.method_10260());
        }

        // Horizontal edges (bottom + top)
        for (int i = 0; i < 4; i++) {
            class_2338 from = corners[i];
            class_2338 to = corners[(i + 1) % 4];
            int steps = Math.max(1, w / 2);
            for (int s = 0; s <= steps; s++) {
                double t = (double) s / steps;
                int x = (int) (from.method_10263() + t * (to.method_10263() - from.method_10263()));
                int z = (int) (from.method_10260() + t * (to.method_10260() - from.method_10260()));
                spawnParticle(world, x, from.method_10264(), z);
                spawnParticle(world, x, from.method_10264() + h - 1, z);
            }
        }
    }

    private void spawnParticle(class_1937 world, int x, int y, int z) {
        if (world instanceof class_3218 sw) {
            sw.method_14199(class_2398.field_11240, x + 0.5, y + 0.5, z + 0.5, 1, 0.1, 0.1, 0.1, 0.01);
        }
    }
}
