package com.example.zombieevolution.network;

import com.example.zombieevolution.*;
import com.example.zombieevolution.handler.ChainMiningHandler;
import com.example.zombieevolution.item.ModItems;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ModPackets {
    private static final Logger LOGGER = LoggerFactory.getLogger("ModPackets");

    public static final class_2960 DAY_SYNC_S2C_ID = ZombieEvolution.id("day_sync");
    public static final class_2960 SET_DAY_C2S_ID = ZombieEvolution.id("set_day");
    public static final class_2960 OPEN_DAY_SETTER_S2C_ID = ZombieEvolution.id("open_day_setter");
    public static final class_2960 CHAIN_MINING_TOGGLE_ID = ZombieEvolution.id("chain_toggle");

    private static int lastSentDay = -1;
    private static int lastSentSpeed = -1;
    private static boolean lastSentLimbs = true;
    private static float lastSentWeight = -1.0f;
    private static boolean lastSentBuildings = true;
    private static int lastSentRarity = 2;

    public static void registerServer() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            class_1937 overworld = server.method_30002();
            if (overworld == null) return;

            int evolutionDay = EvolutionManager.getAnnouncedEvolutionDay(overworld);
            if (evolutionDay > 0) {
                broadcastEvolution(server, evolutionDay);
            }

            if (server.method_3780() % 20 != 0) return;

            int day = EvolutionManager.getCurrentDay(overworld);
            int speed = TimeSpeedManager.getTimeSpeed();
            boolean limbsOn = LimbPhysicsManager.isLimbsEnabled();
            float weight = LimbPhysicsManager.getLimbWeight();
            boolean buildingsOn = ModConfig.isBuildingsEnabled();
            int rarity = ModConfig.getBuildingRarity();

            if (day == lastSentDay && speed == lastSentSpeed && limbsOn == lastSentLimbs
                    && Float.compare(weight, lastSentWeight) == 0
                    && buildingsOn == lastSentBuildings && rarity == lastSentRarity) {
                return;
            }

            lastSentDay = day;
            lastSentSpeed = speed;
            lastSentLimbs = limbsOn;
            lastSentWeight = weight;
            lastSentBuildings = buildingsOn;
            lastSentRarity = rarity;

            var players = server.method_3760().method_14571();
            for (class_3222 player : players) {
                if (ServerPlayNetworking.canSend(player, DAY_SYNC_S2C_ID)) {
                    var buf = PacketByteBufs.create();
                    buf.writeInt(day);
                    buf.writeInt(speed);
                    buf.writeBoolean(limbsOn);
                    buf.writeFloat(weight);
                    buf.writeBoolean(buildingsOn);
                    buf.writeInt(rarity);
                    ServerPlayNetworking.send(player, DAY_SYNC_S2C_ID, buf);
                }
            }
        });

        ServerPlayNetworking.registerGlobalReceiver(SET_DAY_C2S_ID, (server, player, handler, buf, responseSender) -> {
            int requestedDay = buf.readInt();
            int timeSpeed = buf.readInt();
            boolean limbsOn = buf.readBoolean();
            float weight = buf.readFloat();
            boolean giveEquip = buf.readBoolean();
            boolean buildingsOn = buf.readBoolean();
            int rarity = buf.readInt();

            server.execute(() -> {
                int safeDay = Math.max(0, requestedDay);
                class_3218 overworld = server.method_30002();
                if (overworld != null) {
                    overworld.method_29199((long) safeDay * 24000L);
                    EvolutionManager.resetAnnouncedStage();
                }
                TimeSpeedManager.setTimeSpeed(timeSpeed);
                LimbPhysicsManager.setLimbsEnabled(limbsOn);
                LimbPhysicsManager.setLimbWeight(weight);
                ModConfig.setBuildingsEnabled(buildingsOn);
                ModConfig.setBuildingRarity(rarity);
                if (giveEquip) {
                    giveStarterEquipment(player);
                }
                LOGGER.info("Player {} set day={} speed={}x limbs={} weight={} equip={} buildings={} rarity={}",
                        player.method_5477().getString(), safeDay, timeSpeed, limbsOn, weight, giveEquip, buildingsOn, rarity);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(CHAIN_MINING_TOGGLE_ID, (server, player, handler, buf, responseSender) -> {
            boolean active = buf.readBoolean();
            server.execute(() -> ChainMiningHandler.setActive(player, active));
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, entity) -> {
            if (!world.field_9236 && player instanceof class_3222 sp) {
                ChainMiningHandler.onBlockBroken((class_3218) world, pos, sp);
            }
        });
    }

    private static void broadcastEvolution(MinecraftServer server, int evolutionDay) {
        class_2561 title = class_2561.method_43470("§c§l第 " + evolutionDay + " 天");
        class_2561 subtitle = class_2561.method_43470("§e僵尸们似乎更强大了");
        String chat = EvolutionManager.getEvolutionChatMessage(evolutionDay);

        var fadePacket = new class_5905(10, 70, 20);
        var subtitlePacket = new class_5903(subtitle);
        var titlePacket = new class_5904(title);

        class_2561 chatMsg = chat.isEmpty() ? null
                : class_2561.method_43470("§5§l⚡ 僵尸进化！ ").method_10852(class_2561.method_43470(chat));

        for (class_3222 player : server.method_3760().method_14571()) {
            player.field_13987.method_14364(fadePacket);
            player.field_13987.method_14364(subtitlePacket);
            player.field_13987.method_14364(titlePacket);
            if (chatMsg != null) {
                player.method_43496(chatMsg);
            }
        }
    }

    private static void giveStarterEquipment(class_3222 player) {
        var inv = player.method_31548();
        inv.method_5448();
        inv.method_7394(new class_1799(class_1802.field_8176, 32));
        inv.method_7394(new class_1799(class_1802.field_8107));
        inv.method_7394(new class_1799(class_1802.field_8102));
        inv.method_7394(new class_1799(class_1802.field_8371));
        inv.method_7394(new class_1799(class_1802.field_8403));
        inv.method_7394(new class_1799(class_1802.field_8475));
        inv.method_7394(new class_1799(class_1802.field_8699));
        inv.method_7394(new class_1799(ModItems.DAY_SETTER));
        inv.method_7394(createGuideBook());
    }

    private static class_1799 createGuideBook() {
        class_1799 book = new class_1799(class_1802.field_8360);
        class_2487 nbt = book.method_7948();
        nbt.method_10582("title", "§5僵尸进化指南");
        nbt.method_10582("author", "§7Mod");
        nbt.method_10556("resolved", true);

        class_2499 pages = new class_2499();
        pages.add(class_2519.method_23256("{\"text\":\"§5§l 僵尸进化\\n\\n§f目标：生存100天！\\n\\n每过10天僵尸会进化一次，获得更强的属性与特殊能力。\\n\\n坚持越久，挑战越大！\"}"));
        pages.add(class_2519.method_23256("{\"text\":\"§l§c 进化阶段\\n\\n§b第10天§r：放置TNT\\n§b第20天§r：破坏方块\\n§b第40天§r：搭建方块\\n§b第60天§r：爬墙\\n§b第80天§r：死亡分裂\\n§b第100天§r：最终阶段\"}"));
        pages.add(class_2519.method_23256("{\"text\":\"§l§c 装备掉落\\n\\n§b第50天+§r：僵尸必定掉落\\n  §5腐化核心\\n\\n可用于合成：\\n§d腐化晶状装备\\n§d（工具/剑/盔甲）\"}"));
        pages.add(class_2519.method_23256("{\"text\":\"§l§c 属性成长\\n\\n§7- 追踪范围扩大\\n§7- 移动速度提升\\n§7- 攻击伤害增加\\n\\n§c越到后期僵尸越强！\\n\\n准备迎接挑战！\"}"));
        pages.add(class_2519.method_23256("{\"text\":\"§l§a 天数设置器\\n\\n§f开局已获得！\\n\\n右键使用可：\\n§7- 设置当前天数\\n§7- 调整时间流速\\n§7- 领取初始装备\\n§7- 开关建筑生成\\n§7- 调整建筑频率\"}"));
        pages.add(class_2519.method_23256("{\"text\":\"§l§c 提示\\n\\n§a- 提前挖矿储备资源\\n§a- 建立防御工事\\n§a- 合成腐化装备\\n§a- 注意僵尸破墙能力\\n\\n§5祝你好运！\"}"));
        nbt.method_10566("pages", pages);

        return book;
    }
}
