package com.example.zombieevolution.entity.client;

import com.example.zombieevolution.entity.ModEntities;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class ModEntityRenderers {
    public static void register() {
        EntityRendererRegistry.register(ModEntities.PHYSICS_LIMB, PhysicsLimbRenderer::new);
        EntityRendererRegistry.register(ModEntities.TNT_ZOMBIE, AbilityZombieRenderer::new);
        EntityRendererRegistry.register(ModEntities.BREAKER_ZOMBIE, AbilityZombieRenderer::new);
        EntityRendererRegistry.register(ModEntities.BUILDER_ZOMBIE, AbilityZombieRenderer::new);
        EntityRendererRegistry.register(ModEntities.CLIMBER_ZOMBIE, AbilityZombieRenderer::new);
        EntityRendererRegistry.register(ModEntities.SPLITTER_ZOMBIE, AbilityZombieRenderer::new);
    }
}
