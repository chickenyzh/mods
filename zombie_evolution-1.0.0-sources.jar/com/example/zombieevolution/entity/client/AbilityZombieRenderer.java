package com.example.zombieevolution.entity.client;

import com.example.zombieevolution.entity.ModEntities;
import com.google.common.collect.ImmutableMap;
import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_1642;
import net.minecraft.class_2960;
import net.minecraft.class_3886;
import net.minecraft.class_5617;

public class AbilityZombieRenderer extends class_3886 {
    private static final Map<class_1299<?>, class_2960> TEXTURES = ImmutableMap.of(
        ModEntities.TNT_ZOMBIE, new class_2960("zombie_evolution", "textures/entity/ability_tnt_zombie.png"),
        ModEntities.BREAKER_ZOMBIE, new class_2960("zombie_evolution", "textures/entity/ability_breaker_zombie.png"),
        ModEntities.BUILDER_ZOMBIE, new class_2960("zombie_evolution", "textures/entity/ability_builder_zombie.png"),
        ModEntities.CLIMBER_ZOMBIE, new class_2960("zombie_evolution", "textures/entity/ability_climber_zombie.png"),
        ModEntities.SPLITTER_ZOMBIE, new class_2960("zombie_evolution", "textures/entity/ability_splitter_zombie.png")
    );

    public AbilityZombieRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public class_2960 method_4163(class_1642 entity) {
        return TEXTURES.getOrDefault(entity.method_5864(), super.method_4163(entity));
    }
}
