package com.example.zombieevolution.entity.client;

import com.example.zombieevolution.entity.PhysicsLimbEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class PhysicsLimbRenderer extends class_897<PhysicsLimbEntity> {
    private static final class_2960[] SKIN_TEXTURES = new class_2960[15];

    static {
        for (int i = 0; i < 15; i++) {
            SKIN_TEXTURES[i] = new class_2960("zombie_evolution", "textures/entity/zombie/zombie_" + i + ".png");
        }
    }

    public PhysicsLimbRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public void render(PhysicsLimbEntity entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight) {
        // Simple rendering - entity is visible via its texture but rendered as minimal visual
        super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
    }

    @Override
    public class_2960 getTextureLocation(PhysicsLimbEntity entity) {
        int skin = entity.getSkinIndex();
        if (skin >= 0 && skin < 15) {
            return SKIN_TEXTURES[skin];
        }
        return SKIN_TEXTURES[0];
    }
}
