package com.example.zombieevolution.entity;

import com.example.zombieevolution.ZombieEvolution;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1642;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public class ModEntities {
    public static final class_1299<PhysicsLimbEntity> PHYSICS_LIMB = register("physics_limb",
            class_1299.class_1300.method_5903(PhysicsLimbEntity::new, class_1311.field_17715)
                    .method_17687(0.3f, 0.3f).method_27299(64).method_27300(1));
    public static final class_1299<TNTZombieEntity> TNT_ZOMBIE = register("ability_tnt_zombie",
            class_1299.class_1300.method_5903(TNTZombieEntity::new, class_1311.field_6302).method_17687(0.6f, 1.95f));
    public static final class_1299<BreakerZombieEntity> BREAKER_ZOMBIE = register("ability_breaker_zombie",
            class_1299.class_1300.method_5903(BreakerZombieEntity::new, class_1311.field_6302).method_17687(0.6f, 1.95f));
    public static final class_1299<BuilderZombieEntity> BUILDER_ZOMBIE = register("ability_builder_zombie",
            class_1299.class_1300.method_5903(BuilderZombieEntity::new, class_1311.field_6302).method_17687(0.6f, 1.95f));
    public static final class_1299<ClimberZombieEntity> CLIMBER_ZOMBIE = register("ability_climber_zombie",
            class_1299.class_1300.method_5903(ClimberZombieEntity::new, class_1311.field_6302).method_17687(0.6f, 1.95f));
    public static final class_1299<SplitterZombieEntity> SPLITTER_ZOMBIE = register("ability_splitter_zombie",
            class_1299.class_1300.method_5903(SplitterZombieEntity::new, class_1311.field_6302).method_17687(0.6f, 1.95f));

    public static void register() {
        FabricDefaultAttributeRegistry.register(TNT_ZOMBIE, class_1642.method_26940());
        FabricDefaultAttributeRegistry.register(BREAKER_ZOMBIE, class_1642.method_26940());
        FabricDefaultAttributeRegistry.register(BUILDER_ZOMBIE, class_1642.method_26940());
        FabricDefaultAttributeRegistry.register(CLIMBER_ZOMBIE, class_1642.method_26940());
        FabricDefaultAttributeRegistry.register(SPLITTER_ZOMBIE, class_1642.method_26940());
    }

    private static <T extends class_1297> class_1299<T> register(String name, class_1299.class_1300<T> builder) {
        return class_2378.method_10230(class_7923.field_41177, ZombieEvolution.id(name), builder.method_5905(name));
    }
}
