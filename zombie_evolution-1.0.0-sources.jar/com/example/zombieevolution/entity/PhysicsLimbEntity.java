package com.example.zombieevolution.entity;

import com.example.zombieevolution.LimbPhysicsManager;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;

public class PhysicsLimbEntity extends class_1297 {

    private static final class_2940<Integer> LIMB_TYPE =
            class_2945.method_12791(PhysicsLimbEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> SKIN_INDEX =
            class_2945.method_12791(PhysicsLimbEntity.class, class_2943.field_13327);
    private static final class_2940<Float> RANDOM_YAW =
            class_2945.method_12791(PhysicsLimbEntity.class, class_2943.field_13320);

    private int age;
    private boolean hasTouchedGround;

    public PhysicsLimbEntity(class_1299<?> type, class_1937 level) {
        super(type, level);
        this.field_5960 = true;
    }

    @Override
    protected void method_5693() {
        this.field_6011.method_12784(LIMB_TYPE, 2);
        this.field_6011.method_12784(SKIN_INDEX, 0);
        this.field_6011.method_12784(RANDOM_YAW, 0.0f);
    }

    public void setLimbType(LimbType type) {
        this.field_6011.method_12778(LIMB_TYPE, type.ordinal());
    }

    public LimbType getLimbType() {
        return LimbType.values()[this.field_6011.method_12789(LIMB_TYPE)];
    }

    public void setSkinIndex(int index) {
        this.field_6011.method_12778(SKIN_INDEX, index);
    }

    public int getSkinIndex() {
        return this.field_6011.method_12789(SKIN_INDEX);
    }

    public int getAge() {
        return this.age;
    }

    public int getMaxAge() {
        return 400;
    }

    public void setRandomYaw(float yaw) {
        this.field_6011.method_12778(RANDOM_YAW, yaw);
    }

    public float getRandomYaw() {
        return this.field_6011.method_12789(RANDOM_YAW);
    }

    @Override
    public boolean method_30949(class_1297 other) {
        return other instanceof PhysicsLimbEntity;
    }

    @Override
    public boolean method_5863() {
        return true;
    }

    @Override
    public boolean method_5810() {
        return !this.method_7325();
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (!this.method_37908().field_9236 && source.method_5529() != null) {
            this.knockback(source.method_5529());
        }
        return false;
    }

    private void knockback(class_1297 attacker) {
        if (attacker == null || this.method_37908().field_9236) return;
        class_243 vel = this.method_18798();
        double dx = this.method_23317() - attacker.method_23317();
        double dz = this.method_23321() - attacker.method_23321();
        double len = Math.sqrt(dx * dx + dz * dz);
        float w = LimbPhysicsManager.getLimbWeight();

        if (len > 0.01) {
            double push = 0.5 / len / w;
            this.method_18800(vel.field_1352 + dx * push, 0.3 / w, vel.field_1350 + dz * push);
        } else {
            this.method_18800(vel.field_1352, 0.3 / w, vel.field_1350);
        }
    }

    @Override
    public void method_5694(class_1657 player) {
        if (!this.method_37908().field_9236 && this.age > 5) {
            class_243 vel = this.method_18798();
            double dx = this.method_23317() - player.method_23317();
            double dz = this.method_23321() - player.method_23321();
            double len = Math.sqrt(dx * dx + dz * dz);
            float w = LimbPhysicsManager.getLimbWeight();

            if (len > 0.01) {
                this.method_18800(
                        vel.field_1352 + dx * 0.15 / len / w,
                        vel.field_1351 + 0.08 / w,
                        vel.field_1350 + dz * 0.15 / len / w
                );
            }
        }
    }

    @Override
    public void method_5762(double dx, double dy, double dz) {
        class_243 vel = this.method_18798();
        this.method_18800(vel.field_1352 + dx, vel.field_1351 + dy, vel.field_1350 + dz);
    }

    @Override
    public void method_5773() {
        double prevX = this.method_23317();
        double prevY = this.method_23318();
        double prevZ = this.method_23321();
        class_1937 w = this.method_37908();

        this.age++;
        if (this.age >= this.getMaxAge()) {
            if (!w.field_9236) {
                for (int i = 0; i < 5; i++) {
                    w.method_8406(
                            new class_2388(class_2398.field_11217, class_2246.field_10515.method_9564()),
                            this.method_23317() + (this.field_5974.method_43058() - 0.5) * 0.4,
                            this.method_23318() + this.field_5974.method_43058() * 0.4,
                            this.method_23321() + (this.field_5974.method_43058() - 0.5) * 0.4,
                            0.0, 0.0, 0.0
                    );
                }
            }
            this.method_5650(class_5529.field_26999);
            return;
        }

        class_243 vel = this.method_18798();

        if (!this.method_5740()) {
            vel = vel.method_1031(0, -0.04, 0);
        }

        if (this.method_5799()) {
            vel = new class_243(vel.field_1352 * 0.85, Math.min(vel.field_1351 + 0.03, 0.1), vel.field_1350 * 0.85);
        } else if (this.method_5771()) {
            this.method_20803(0);
            this.method_5646();
            vel = new class_243(vel.field_1352 * 0.8, vel.field_1351, vel.field_1350 * 0.8);
        } else {
            vel = new class_243(vel.field_1352 * 0.99, vel.field_1351, vel.field_1350 * 0.99);
        }

        // Cap speed
        double maxSpeed = 2.5;
        double speedSq = vel.field_1352 * vel.field_1352 + vel.field_1351 * vel.field_1351 + vel.field_1350 * vel.field_1350;
        if (speedSq > maxSpeed * maxSpeed) {
            vel = vel.method_1021(maxSpeed / Math.sqrt(speedSq));
        }

        this.method_18799(vel);

        double intendedX = vel.field_1352;
        double intendedY = vel.field_1351;
        double intendedZ = vel.field_1350;

        this.method_5784(class_1313.field_6308, vel);

        double actualX = this.method_23317() - prevX;
        double actualY = this.method_23318() - prevY;
        double actualZ = this.method_23321() - prevZ;

        class_243 newVel = this.method_18798();

        if (Math.abs(intendedX - actualX) > 0.001) {
            newVel = new class_243(-intendedX * 0.35, newVel.field_1351, newVel.field_1350);
        }

        if (Math.abs(intendedZ - actualZ) > 0.001) {
            newVel = new class_243(newVel.field_1352, newVel.field_1351, -intendedZ * 0.35);
        }

        if (Math.abs(intendedY - actualY) > 0.001 && intendedY < 0) {
            newVel = new class_243(newVel.field_1352, -intendedY * 0.2, newVel.field_1350);
        }

        this.method_18799(newVel);
    }

    @Override
    protected void method_5749(class_2487 nbt) {
        this.field_6011.method_12778(LIMB_TYPE, nbt.method_10550("LimbType"));
        this.field_6011.method_12778(SKIN_INDEX, nbt.method_10550("SkinIndex"));
        this.age = nbt.method_10550("Age");
        this.hasTouchedGround = nbt.method_10577("TouchedGround");
    }

    @Override
    protected void method_5652(class_2487 nbt) {
        nbt.method_10569("LimbType", this.field_6011.method_12789(LIMB_TYPE));
        nbt.method_10569("SkinIndex", this.field_6011.method_12789(SKIN_INDEX));
        nbt.method_10569("Age", this.age);
        nbt.method_10556("TouchedGround", this.hasTouchedGround);
    }

    public enum LimbType {
        HEAD(1.0f),
        TORSO(1.0f),
        ARM_LEFT(1.0f),
        ARM_RIGHT(1.0f),
        LEG_LEFT(1.0f),
        LEG_RIGHT(1.0f);

        private final float scale;

        LimbType(float scale) {
            this.scale = scale;
        }

        public float getScale() {
            return scale;
        }
    }
}
