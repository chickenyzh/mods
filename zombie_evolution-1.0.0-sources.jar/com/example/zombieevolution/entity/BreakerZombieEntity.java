package com.example.zombieevolution.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1352;
import net.minecraft.class_1642;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class BreakerZombieEntity extends class_1642 {
    public BreakerZombieEntity(class_1299<? extends class_1642> type, class_1937 level) {
        super(type, level);
    }

    @Override
    protected void method_5959() {
        super.method_5959();
        this.field_6201.method_6277(1, new BreakBlockGoal(this));
    }

    static class BreakBlockGoal extends class_1352 {
        private final BreakerZombieEntity zombie;
        private int breakTick = 0;

        BreakBlockGoal(BreakerZombieEntity z) {
            this.zombie = z;
        }

        @Override
        public boolean method_6264() {
            return this.zombie.method_5968() != null;
        }

        @Override
        public void method_6268() {
            if (this.zombie.method_5968() == null) return;

            class_2338 pos = this.zombie.method_24515().method_10093(this.zombie.method_5735());
            class_2680 state = this.zombie.method_37908().method_8320(pos);

            if (!state.method_26215()
                    && state.method_26214(this.zombie.method_37908(), pos) >= 0
                    && state.method_26214(this.zombie.method_37908(), pos) < 50) {
                breakTick++;
                if (breakTick >= 20) {
                    this.zombie.method_37908().method_22352(pos, true);
                    breakTick = 0;
                }
            } else {
                breakTick = 0;
            }
        }
    }
}
