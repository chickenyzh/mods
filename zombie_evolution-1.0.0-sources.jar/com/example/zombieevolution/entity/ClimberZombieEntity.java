package com.example.zombieevolution.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1642;
import net.minecraft.class_1937;

public class ClimberZombieEntity extends class_1642 {
    public ClimberZombieEntity(class_1299<? extends class_1642> type, class_1937 level) {
        super(type, level);
    }

    @Override
    public boolean method_6101() {
        return this.field_5976;
    }
}
