package com.example.zombieevolution.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1352;
import net.minecraft.class_1642;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

public class BuilderZombieEntity extends class_1642 {
    public BuilderZombieEntity(class_1299<? extends class_1642> type, class_1937 level) {
        super(type, level);
    }

    @Override
    protected void method_5959() {
        super.method_5959();
        this.field_6201.method_6277(1, new PlaceBlockGoal(this));
    }

    static class PlaceBlockGoal extends class_1352 {
        private final BuilderZombieEntity zombie;
        private int placeTick = 0;

        PlaceBlockGoal(BuilderZombieEntity z) {
            this.zombie = z;
        }

        @Override
        public boolean method_6264() {
            return this.zombie.method_5968() != null;
        }

        @Override
        public void method_6268() {
            if (this.zombie.method_5968() == null) return;

            placeTick++;
            if (placeTick < 40) return;
            placeTick = 0;

            class_2350 direction = this.zombie.method_5735();
            class_2338 pos = this.zombie.method_24515().method_10093(direction);
            class_2680 state = this.zombie.method_37908().method_8320(pos);

            if (state.method_26215() || state.method_45474()) {
                this.zombie.method_37908().method_8652(pos, class_2246.field_10445.method_9564(), 3);
            }
        }
    }
}
