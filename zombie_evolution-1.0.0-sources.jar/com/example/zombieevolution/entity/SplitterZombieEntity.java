package com.example.zombieevolution.entity;

import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1642;
import net.minecraft.class_1937;

public class SplitterZombieEntity extends class_1642 {
    public SplitterZombieEntity(class_1299<? extends class_1642> type, class_1937 level) {
        super(type, level);
    }

    @Override
    public void method_6078(class_1282 source) {
        if (!this.method_37908().field_9236) {
            int count = 2 + this.field_5974.method_43048(2);
            for (int i = 0; i < count; i++) {
                class_1642 baby = class_1299.field_6051.method_5883(this.method_37908());
                if (baby != null) {
                    baby.method_7217(true);
                    baby.method_5814(
                        this.method_23317() + this.field_5974.method_43058() - 0.5,
                        this.method_23318(),
                        this.method_23321() + this.field_5974.method_43058() - 0.5
                    );
                    this.method_37908().method_8649(baby);
                }
            }
        }
        super.method_6078(source);
    }
}
