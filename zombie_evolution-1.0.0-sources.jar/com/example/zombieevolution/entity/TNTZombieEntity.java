package com.example.zombieevolution.entity;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1642;
import net.minecraft.class_1937;

public class TNTZombieEntity extends class_1642 {
    public TNTZombieEntity(class_1299<? extends class_1642> type, class_1937 level) {
        super(type, level);
    }

    @Override
    public void method_6078(class_1282 source) {
        if (!this.method_37908().field_9236) {
            this.method_37908().method_8437(this, this.method_23317(), this.method_23318(), this.method_23321(), 2.0f, class_1937.class_7867.field_40890);
        }
        super.method_6078(source);
    }

    @Override
    public boolean method_6121(class_1297 target) {
        boolean hurt = super.method_6121(target);
        if (hurt && !this.method_37908().field_9236 && this.field_5974.method_43057() < 0.3f) {
            this.method_37908().method_8437(this, this.method_23317(), this.method_23318(), this.method_23321(), 1.5f, class_1937.class_7867.field_40890);
        }
        return hurt;
    }
}
