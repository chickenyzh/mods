package com.example.zombieevolution.util;

import net.minecraft.class_1642;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;

public class ModDataComponents {
	public static final class_2940<Integer> DATA_SKIN_INDEX = class_2945.method_12791(
		class_1642.class, class_2943.field_13327
	);
}
