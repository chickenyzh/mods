package com.example.zombieevolution.world.gen;

import com.example.zombieevolution.ModConfig;
import com.example.zombieevolution.ModStructures;
import com.example.zombieevolution.ZombieEvolution;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_5821;

public class BuildingFeature extends class_3031<class_3111> {

    public BuildingFeature() {
        super(class_3111.field_24893);
    }

    @Override
    public boolean method_13151(class_5821<class_3111> context) {
        var world = context.method_33652();
        var chunkOrigin = context.method_33655();
        var random = context.method_33654();

        if (!ModConfig.isBuildingsEnabled()) return false;

        var building = ModStructures.getRandomBuilding(random);
        if (building == null || building.size == null) return false;

        int w = building.size[0];
        int d = building.size[2];
        int h = building.size[1];

        int originX = chunkOrigin.method_10263() + random.method_43048(4);
        int originZ = chunkOrigin.method_10260() + random.method_43048(4);
        int surfaceY = world.method_8624(class_2902.class_2903.field_13194, originX, originZ);
        class_2338 origin = new class_2338(originX, surfaceY, originZ);

        // Surface check: reject if any surface block is water or lava
        for (int x = 0; x < w; x++) {
            for (int z = 0; z < d; z++) {
                class_2248 block = world.method_8320(origin.method_10069(x, 0, z)).method_26204();
                if (block == class_2246.field_10382 || block == class_2246.field_10164) {
                    return false;
                }
            }
        }

        // Second surface check: ensure at least 50% of sampled points have solid ground
        int solidSamples = 0;
        int totalSamples = 0;
        for (int x = 0; x < w; x += 3) {
            for (int z = 0; z < d; z += 3) {
                totalSamples++;
                class_2338 check = origin.method_10069(x, 0, z);
                class_2680 state = world.method_8320(check);
                if (!state.method_26215() && state.method_26204() != class_2246.field_10382 && state.method_26204() != class_2246.field_10164) {
                    solidSamples++;
                }
            }
        }
        if (totalSamples > 0 && (float)solidSamples / totalSamples < 0.5f) {
            return false;
        }

        // Fill building volume: replace non-air blocks with stone to fill caves
        ZombieEvolution.LOGGER.info("BuildingFeature: surfaceY={}, seaLevel={} at {},{}, building={}x{}",
                surfaceY, world.method_8615(), originX, originZ, w, d);

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                for (int z = 0; z < d; z++) {
                    class_2338 pos = origin.method_10069(x, y, z);
                    class_2248 block = world.method_8320(pos).method_26204();
                    if (block != class_2246.field_10543 && block != class_2246.field_10477 && block != class_2246.field_10124) {
                        world.method_8652(pos, class_2246.field_10340.method_9564(), 3);
                    }
                }
            }
        }

        // Foundation fill: fill below surface with cobblestone
        for (int x = 0; x < w; x++) {
            for (int z = 0; z < d; z++) {
                class_2338.class_2339 cursor = origin.method_10069(x, -1, z).method_25503();
                int maxFill = 12;
                for (int i = 0; i < maxFill && cursor.method_10264() > world.method_8615(); i++) {
                    if (world.method_8320(cursor).method_26215()) {
                        world.method_8652(cursor, class_2246.field_10445.method_9564(), 3);
                    }
                    cursor.method_10100(0, -1, 0);
                }
            }
        }

        // Place building structure
        ZombieEvolution.LOGGER.info("BuildingFeature: placing {} at {}", building.name, origin);
        var placed = ModStructures.placeRandomBuilding(world, origin, random);

        // If "building_4", set world spawn point
        if (placed != null && "building_4".equals(placed.name)) {
            class_2338 spawnPos = origin.method_10069(4, 1, 3);
            var server = world.method_8503();
            if (server != null && server.method_30002() != null) {
                server.method_30002().method_8554(spawnPos, 0.0f);
            }
        }

        return true;
    }
}
