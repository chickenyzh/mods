package com.example.zombieevolution.world.gen;

import com.example.zombieevolution.ModStructures;
import com.example.zombieevolution.ZombieEvolution;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.event.registry.DynamicRegistrySetupCallback;
import net.minecraft.class_2378;
import net.minecraft.class_2893;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5925;
import net.minecraft.class_6796;
import net.minecraft.class_6799;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.world.level.levelgen.placement.*;

import java.util.List;

public class ModWorldGen {
    private static final class_2960 BUILDING_ID = new class_2960(ZombieEvolution.MOD_ID, "jungle_treehouse");

    public static void register() {
        class_2378.method_10230(class_7923.field_41144, BUILDING_ID, new BuildingFeature());
        ModStructures.register();

        DynamicRegistrySetupCallback.EVENT.register(ctx -> {
            var registryAccess = ctx.asDynamicRegistryManager();

            // Register configured feature
            var cfRegOpt = registryAccess.method_33310(class_7924.field_41239);
            if (cfRegOpt.isEmpty()) return;
            var cfReg = cfRegOpt.get();

            if (cfReg.method_17966(BUILDING_ID).isEmpty()) {
                class_3031<class_3111> feature = (class_3031<class_3111>) class_7923.field_41144.method_10223(BUILDING_ID);
                if (feature != null) {
                    class_2378.method_10230(cfReg, BUILDING_ID,
                            new class_2975<>(feature, class_3111.field_24894));
                }
            }

            // Register placed feature
            var pfRegOpt = registryAccess.method_33310(class_7924.field_41245);
            if (pfRegOpt.isEmpty()) return;
            var pfReg = pfRegOpt.get();

            if (pfReg.method_17966(BUILDING_ID).isEmpty()) {
                var cfKey = class_5321.method_29179(class_7924.field_41239, BUILDING_ID);
                var cfHolder = cfReg.method_40264(cfKey);
                if (cfHolder.isPresent()) {
                    class_2378.method_10230(pfReg, BUILDING_ID, new class_6796(
                            cfHolder.get(),
                            List.of(
                                    class_6799.method_39659(80),
                                    class_5450.method_39639(),
                                    class_5925.method_39638(class_2902.class_2903.field_13194)
                            )
                    ));
                }
            }
        });

        BiomeModifications.addFeature(
                BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13172,
                class_5321.method_29179(class_7924.field_41245, BUILDING_ID)
        );
    }
}
