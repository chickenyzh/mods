package com.example.zombieevolution.handler;

import com.example.zombieevolution.ModStructures;
import com.example.zombieevolution.StructureLoot;
import com.example.zombieevolution.StructureManager;
import com.example.zombieevolution.StructureManager.SavedBuilding;
import com.example.zombieevolution.WorldState;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SpawnShelterHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger("SpawnShelterHandler");

    public static void tryPlaceShelter(MinecraftServer server) {
        WorldState state = WorldState.get(server);
        if (state == null || state.isShelterPlaced()) return;

        class_3218 overworld = server.method_30002();
        if (overworld == null) return;

        SavedBuilding building = ModStructures.getShelterBuilding();
        if (building == null || building.size == null) return;

        int w = building.size[0];
        int h = building.size[1];
        int d = building.size[2];

        class_2338 spawnPos = overworld.method_43126();
        int surfaceY = overworld.method_8624(class_2902.class_2903.field_13202, spawnPos.method_10263(), spawnPos.method_10260());
        class_2338 origin = new class_2338(spawnPos.method_10263() - 4, surfaceY, spawnPos.method_10260() - 3);

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                for (int z = 0; z < d; z++) {
                    class_2338 p = origin.method_10069(x, y, z);
                    class_2248 block = overworld.method_8320(p).method_26204();
                    if (block == class_2246.field_10219 || block == class_2246.field_10340 || block == class_2246.field_10566) continue;
                    overworld.method_30092(p, class_2246.field_10340.method_9564(), 3, 0);
                }
            }
        }

        StructureManager.placeBuilding(overworld, origin, building);
        StructureLoot.fillChests(overworld, origin, building, class_5819.method_43047());

        class_2338 seaLanternPos = origin.method_10069(4, 1, 3);
        overworld.method_8554(seaLanternPos, 0.0f);
        LOGGER.info("Shelter placed at origin={}, spawn set to {}", origin, seaLanternPos);
        state.setShelterPlaced(true);
    }
}
