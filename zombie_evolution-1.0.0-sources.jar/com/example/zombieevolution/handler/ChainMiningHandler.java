package com.example.zombieevolution.handler;

import java.util.*;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class ChainMiningHandler {

    private static final Set<UUID> activePlayers = new HashSet<>();
    private static final int ORE_LIMIT = 256;
    private static final Set<class_2248> ORE_BLOCKS = new HashSet<>(Arrays.asList(
            class_2246.field_10418, class_2246.field_29219,
            class_2246.field_10212, class_2246.field_29027,
            class_2246.field_27120, class_2246.field_29221,
            class_2246.field_10571, class_2246.field_29026,
            class_2246.field_10442, class_2246.field_29029,
            class_2246.field_10013, class_2246.field_29220,
            class_2246.field_10090, class_2246.field_29028,
            class_2246.field_10080, class_2246.field_29030,
            class_2246.field_10213,
            class_2246.field_23077,
            class_2246.field_22109
    ));

    public static void setActive(class_3222 player, boolean active) {
        UUID uuid = player.method_5667();
        if (active) {
            activePlayers.add(uuid);
        } else {
            activePlayers.remove(uuid);
        }
    }

    public static boolean isActive(class_3222 player) {
        return activePlayers.contains(player.method_5667());
    }

    public static void onBlockBroken(class_3218 world, class_2338 pos, class_3222 player) {
        if (!isActive(player)) return;

        class_2680 original = world.method_8320(pos);
        if (original.method_26215()) return;

        boolean isOre = ORE_BLOCKS.contains(original.method_26204());
        class_1799 tool = player.method_6047();

        if (isOre) {
            breakOreChain(world, pos, original.method_26204(), player, tool);
        } else {
            breakCubic(world, pos, original.method_26204(), player, tool);
        }
    }

    private static void breakCubic(class_3218 world, class_2338 origin, class_2248 target, class_3222 player, class_1799 tool) {
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    if (x == 0 && y == 0 && z == 0) continue;

                    class_2338 bp = origin.method_10069(x, y, z);

                    if (!world.method_8505(player, bp)) continue;
                    if (!world.method_8320(bp).method_27852(target)) continue;

                    destroyBlock(world, bp, player, tool);
                }
            }
        }
    }

    private static void breakOreChain(class_3218 world, class_2338 origin, class_2248 target, class_3222 player, class_1799 tool) {
        Set<class_2338> visited = new LinkedHashSet<>();
        Queue<class_2338> queue = new ArrayDeque<>();

        queue.add(origin);
        visited.add(origin);

        while (!queue.isEmpty() && visited.size() < ORE_LIMIT) {
            class_2338 current = queue.poll();

            for (int x = -1; x <= 1; x++) {
                for (int y = -1; y <= 1; y++) {
                    for (int z = -1; z <= 1; z++) {
                        if (x == 0 && y == 0 && z == 0) continue;

                        class_2338 next = current.method_10069(x, y, z);

                        if (visited.contains(next)) continue;
                        if (!world.method_24794(next)) continue;
                        if (!world.method_8505(player, next)) continue;
                        if (!world.method_8320(next).method_27852(target)) continue;

                        visited.add(next);
                        queue.add(next);
                    }
                }
            }
        }

        for (class_2338 bp : visited) {
            if (bp.equals(origin)) continue;
            destroyBlock(world, bp, player, tool);
        }
    }

    private static void destroyBlock(class_3218 world, class_2338 pos, class_3222 player, class_1799 tool) {
        class_2680 state = world.method_8320(pos);
        if (state.method_26215()) return;

        state.method_26204().method_9576(world, pos, state, player);
        world.method_8650(pos, false);
        world.method_20290(2001, pos, class_2248.method_9507(state));

        if (!tool.method_7960() && tool.method_7963()) {
            tool.method_7952(world, state, pos, player);
        }
    }
}
