package com.example.zombieevolution.item;

import net.minecraft.class_1832;
import net.minecraft.class_1856;

public class CorruptedCrystalToolMaterial implements class_1832 {
    public static final CorruptedCrystalToolMaterial INSTANCE = new CorruptedCrystalToolMaterial();

    @Override public int method_8025() { return 2500; }
    @Override public float method_8027() { return 12.0f; }
    @Override public float method_8028() { return 5.0f; }
    @Override public int method_8024() { return 4; }
    @Override public int method_8026() { return 20; }
    @Override public class_1856 method_8023() { return class_1856.method_8091(ModItems.CORRUPTED_CRYSTAL_INGOT); }
}
