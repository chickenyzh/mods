package com.example.zombieevolution.item;

import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

public class CompoundCorruptCrystalArmorMaterial implements class_1741 {
    public static final CompoundCorruptCrystalArmorMaterial INSTANCE = new CompoundCorruptCrystalArmorMaterial();
    private static final int[] DURABILITY_MULTIPLIER = {15, 18, 20, 14};
    private static final int[] PROTECTION = {5, 8, 10, 5};

    @Override public int method_48402(class_1738.class_8051 type) { return DURABILITY_MULTIPLIER[type.ordinal()] * 50; }
    @Override public int method_48403(class_1738.class_8051 type) { return PROTECTION[type.ordinal()]; }
    @Override public int method_7699() { return 25; }
    @Override public class_3414 method_7698() { return class_3417.field_15103; }
    @Override public class_1856 method_7695() { return class_1856.method_8091(ModItems.COMPOUND_CORRUPT_CRYSTAL_INGOT); }
    @Override public String method_7694() { return "compound_corrupt_crystal"; }
    @Override public float method_7700() { return 5.0f; }
    @Override public float method_24355() { return 0.2f; }
}
