package com.example.zombieevolution.item;

import com.example.zombieevolution.ZombieEvolution;
import com.example.zombieevolution.entity.ModEntities;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1810;
import net.minecraft.class_1814;
import net.minecraft.class_1826;
import net.minecraft.class_1829;
import net.minecraft.class_2378;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.world.item.*;

import java.util.Map;

public class ModItems {
    public static void register() {
        register(DAY_SETTER, "day_setter");
        register(CORRUPTED_CORE, "corrupted_core");
        register(CORRUPTED_CRYSTAL_INGOT, "corrupted_crystal_ingot");
        register(CORRUPTED_CRYSTAL_SWORD, "corrupted_crystal_sword");
        register(CORRUPTED_CRYSTAL_PICKAXE, "corrupted_crystal_pickaxe");
        register(CORRUPTED_CRYSTAL_AXE, "corrupted_crystal_axe");
        register(CORRUPTED_CRYSTAL_HELMET, "corrupted_crystal_helmet");
        register(CORRUPTED_CRYSTAL_CHESTPLATE, "corrupted_crystal_chestplate");
        register(CORRUPTED_CRYSTAL_LEGGINGS, "corrupted_crystal_leggings");
        register(CORRUPTED_CRYSTAL_BOOTS, "corrupted_crystal_boots");
        register(ABILITY_TNT_EGG, "ability_tnt_egg");
        register(ABILITY_BREAKER_EGG, "ability_breaker_egg");
        register(ABILITY_BUILDER_EGG, "ability_builder_egg");
        register(ABILITY_CLIMBER_EGG, "ability_climber_egg");
        register(ABILITY_SPLITTER_EGG, "ability_splitter_egg");
        register(COMPOUND_CORRUPT_CRYSTAL_UPGRADE_TEMPLATE, "compound_corrupt_crystal_upgrade_template");
        register(COMPOUND_CORRUPT_CRYSTAL_INGOT, "compound_corrupt_crystal_ingot");
        register(COMPOUND_CORRUPT_CRYSTAL_SWORD, "compound_corrupt_crystal_sword");
        register(COMPOUND_CORRUPT_CRYSTAL_PICKAXE, "compound_corrupt_crystal_pickaxe");
        register(COMPOUND_CORRUPT_CRYSTAL_AXE, "compound_corrupt_crystal_axe");
        register(COMPOUND_CORRUPT_CRYSTAL_HELMET, "compound_corrupt_crystal_helmet");
        register(COMPOUND_CORRUPT_CRYSTAL_CHESTPLATE, "compound_corrupt_crystal_chestplate");
        register(COMPOUND_CORRUPT_CRYSTAL_LEGGINGS, "compound_corrupt_crystal_leggings");
        register(COMPOUND_CORRUPT_CRYSTAL_BOOTS, "compound_corrupt_crystal_boots");

        // Creative tabs
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            entries.method_45421(DAY_SETTER);
            entries.method_45421(CORRUPTED_CRYSTAL_SWORD);
            entries.method_45421(CORRUPTED_CRYSTAL_PICKAXE);
            entries.method_45421(CORRUPTED_CRYSTAL_AXE);
            entries.method_45421(COMPOUND_CORRUPT_CRYSTAL_SWORD);
            entries.method_45421(COMPOUND_CORRUPT_CRYSTAL_PICKAXE);
            entries.method_45421(COMPOUND_CORRUPT_CRYSTAL_AXE);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(entries -> {
            entries.method_45421(CORRUPTED_CRYSTAL_SWORD);
            entries.method_45421(CORRUPTED_CRYSTAL_HELMET);
            entries.method_45421(CORRUPTED_CRYSTAL_CHESTPLATE);
            entries.method_45421(CORRUPTED_CRYSTAL_LEGGINGS);
            entries.method_45421(CORRUPTED_CRYSTAL_BOOTS);
            entries.method_45421(COMPOUND_CORRUPT_CRYSTAL_SWORD);
            entries.method_45421(COMPOUND_CORRUPT_CRYSTAL_HELMET);
            entries.method_45421(COMPOUND_CORRUPT_CRYSTAL_CHESTPLATE);
            entries.method_45421(COMPOUND_CORRUPT_CRYSTAL_LEGGINGS);
            entries.method_45421(COMPOUND_CORRUPT_CRYSTAL_BOOTS);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries -> {
            entries.method_45421(CORRUPTED_CORE);
            entries.method_45421(CORRUPTED_CRYSTAL_INGOT);
            entries.method_45421(COMPOUND_CORRUPT_CRYSTAL_UPGRADE_TEMPLATE);
            entries.method_45421(COMPOUND_CORRUPT_CRYSTAL_INGOT);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(entries -> {
            entries.method_45421(ABILITY_TNT_EGG);
            entries.method_45421(ABILITY_BREAKER_EGG);
            entries.method_45421(ABILITY_BUILDER_EGG);
            entries.method_45421(ABILITY_CLIMBER_EGG);
            entries.method_45421(ABILITY_SPLITTER_EGG);
        });
    }

    private static void register(class_1792 item, String name) {
        class_2378.method_10230(class_7923.field_41178, ZombieEvolution.id(name), item);
    }

    // ===== Day Setter =====
    public static final class_1792 DAY_SETTER = new DaySetterItem(
            new FabricItemSettings().maxCount(1).method_7894(class_1814.field_8903).fireproof());

    // ===== Corrupted Crystal Materials =====
    public static final class_1792 CORRUPTED_CORE = new class_1792(
            new FabricItemSettings().method_7894(class_1814.field_8907));
    public static final class_1792 CORRUPTED_CRYSTAL_INGOT = new class_1792(
            new FabricItemSettings().method_7894(class_1814.field_8907).fireproof());

    // ===== Corrupted Crystal Tools =====
    public static final class_1792 CORRUPTED_CRYSTAL_SWORD = new class_1829(
            CorruptedCrystalToolMaterial.INSTANCE, 4, -2.2f,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));
    public static final class_1792 CORRUPTED_CRYSTAL_PICKAXE = new class_1810(
            CorruptedCrystalToolMaterial.INSTANCE, 1, -2.6f,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));
    public static final class_1792 CORRUPTED_CRYSTAL_AXE = new class_1743(
            CorruptedCrystalToolMaterial.INSTANCE, 6.0f, -2.8f,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));

    // ===== Corrupted Crystal Armor =====
    public static final class_1792 CORRUPTED_CRYSTAL_HELMET = new class_1738(
            CorruptedCrystalArmorMaterial.INSTANCE, class_1738.class_8051.field_41934,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));
    public static final class_1792 CORRUPTED_CRYSTAL_CHESTPLATE = new class_1738(
            CorruptedCrystalArmorMaterial.INSTANCE, class_1738.class_8051.field_41935,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));
    public static final class_1792 CORRUPTED_CRYSTAL_LEGGINGS = new class_1738(
            CorruptedCrystalArmorMaterial.INSTANCE, class_1738.class_8051.field_41936,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));
    public static final class_1792 CORRUPTED_CRYSTAL_BOOTS = new class_1738(
            CorruptedCrystalArmorMaterial.INSTANCE, class_1738.class_8051.field_41937,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));

    // ===== Ability Spawn Eggs =====
    public static final class_1792 ABILITY_TNT_EGG = new class_1826(
            ModEntities.TNT_ZOMBIE, 0x2E8B57, 0x8B0000, new class_1792.class_1793());
    public static final class_1792 ABILITY_BREAKER_EGG = new class_1826(
            ModEntities.BREAKER_ZOMBIE, 0xB8860B, 0xFF4500, new class_1792.class_1793());
    public static final class_1792 ABILITY_BUILDER_EGG = new class_1826(
            ModEntities.BUILDER_ZOMBIE, 0x4682B4, 0x87CEEB, new class_1792.class_1793());
    public static final class_1792 ABILITY_CLIMBER_EGG = new class_1826(
            ModEntities.CLIMBER_ZOMBIE, 0x556B2F, 0x8FBC8F, new class_1792.class_1793());
    public static final class_1792 ABILITY_SPLITTER_EGG = new class_1826(
            ModEntities.SPLITTER_ZOMBIE, 0x8B008B, 0xFF69B4, new class_1792.class_1793());

    // ===== Compound Corrupt Crystal Materials =====
    public static final class_1792 COMPOUND_CORRUPT_CRYSTAL_UPGRADE_TEMPLATE = new class_1792(
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8904));
    public static final class_1792 COMPOUND_CORRUPT_CRYSTAL_INGOT = new class_1792(
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));

    // ===== Compound Corrupt Crystal Tools =====
    public static final class_1792 COMPOUND_CORRUPT_CRYSTAL_SWORD = new class_1829(
            CompoundCorruptCrystalToolMaterial.INSTANCE, 20, -2.4f,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));
    public static final class_1792 COMPOUND_CORRUPT_CRYSTAL_PICKAXE = new class_1810(
            CompoundCorruptCrystalToolMaterial.INSTANCE, 1, -2.6f,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));
    public static final class_1792 COMPOUND_CORRUPT_CRYSTAL_AXE = new class_1743(
            CompoundCorruptCrystalToolMaterial.INSTANCE, 30.0f, -3.0f,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));

    // ===== Compound Corrupt Crystal Armor =====
    public static final class_1792 COMPOUND_CORRUPT_CRYSTAL_HELMET = new class_1738(
            CompoundCorruptCrystalArmorMaterial.INSTANCE, class_1738.class_8051.field_41934,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));
    public static final class_1792 COMPOUND_CORRUPT_CRYSTAL_CHESTPLATE = new class_1738(
            CompoundCorruptCrystalArmorMaterial.INSTANCE, class_1738.class_8051.field_41935,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));
    public static final class_1792 COMPOUND_CORRUPT_CRYSTAL_LEGGINGS = new class_1738(
            CompoundCorruptCrystalArmorMaterial.INSTANCE, class_1738.class_8051.field_41936,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));
    public static final class_1792 COMPOUND_CORRUPT_CRYSTAL_BOOTS = new class_1738(
            CompoundCorruptCrystalArmorMaterial.INSTANCE, class_1738.class_8051.field_41937,
            new FabricItemSettings().fireproof().method_7894(class_1814.field_8903));
}
