package com.example.zombieevolution.item;

import com.example.zombieevolution.EvolutionManager;
import com.example.zombieevolution.network.ModPackets;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;

public class DaySetterItem extends class_1792 {
    public DaySetterItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (!level.field_9236 && player instanceof class_3222 serverPlayer) {
            int day = EvolutionManager.getCurrentDay(level);
            var buf = PacketByteBufs.create();
            buf.writeInt(day);
            ServerPlayNetworking.send(serverPlayer, ModPackets.OPEN_DAY_SETTER_S2C_ID, buf);
        }
        return class_1271.method_22427(player.method_5998(hand));
    }
}
