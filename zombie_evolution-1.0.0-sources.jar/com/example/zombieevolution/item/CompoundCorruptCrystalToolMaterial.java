package com.example.zombieevolution.item;

import net.minecraft.class_1832;
import net.minecraft.class_1856;

public class CompoundCorruptCrystalToolMaterial implements class_1832 {
    public static final CompoundCorruptCrystalToolMaterial INSTANCE = new CompoundCorruptCrystalToolMaterial();

    @Override public int method_8025() { return 4000; }
    @Override public float method_8027() { return 14.0f; }
    @Override public float method_8028() { return 5.0f; }
    @Override public int method_8024() { return 4; }
    @Override public int method_8026() { return 25; }
    @Override public class_1856 method_8023() { return class_1856.method_8091(ModItems.COMPOUND_CORRUPT_CRYSTAL_INGOT); }
}
