package com.example.zombieevolution.client.render.feature;

import com.example.zombieevolution.ZombieEvolution;
import net.minecraft.class_1642;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_623;
import net.minecraft.class_922;

public class ZombieEyesFeatureRenderer extends class_3887<class_1642, class_623<class_1642>> {

    private static final class_1921 EYES = class_1921.method_23026(
            new class_2960(ZombieEvolution.MOD_ID, "textures/entity/zombie/eyes.png"));

    public ZombieEyesFeatureRenderer(class_922<class_1642, class_623<class_1642>> parent) {
        super(parent);
    }

    @Override
    public void render(class_4587 matrices, class_4597 vertexConsumers, int light, class_1642 entity, float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        class_4588 consumer = vertexConsumers.getBuffer(EYES);
        this.method_17165().method_2828(matrices, consumer, 15728640, class_4608.field_21444, 1.0f, 1.0f, 1.0f, 1.0f);
    }
}
