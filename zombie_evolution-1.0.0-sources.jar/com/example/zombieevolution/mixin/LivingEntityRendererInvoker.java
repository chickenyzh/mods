package com.example.zombieevolution.mixin;

import net.minecraft.class_3887;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_922.class)
public interface LivingEntityRendererInvoker {
    @Invoker("addLayer")
    boolean invokeAddFeature(class_3887<?, ?> feature);
}
