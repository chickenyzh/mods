package com.example.zombieevolution.mixin;

import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {

	@Inject(method = "render", at = @At("TAIL"))
	private void onRender(class_332 guiGraphics, float partialTick, CallbackInfo ci) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1687 == null || mc.field_1724 == null) return;

		long day = mc.field_1687.method_8510() / 24000L + 1;
		guiGraphics.method_51433(mc.field_1772, "§c第 " + day + " 天", 4, 4, 0xFFFFFF, false);
	}
}
