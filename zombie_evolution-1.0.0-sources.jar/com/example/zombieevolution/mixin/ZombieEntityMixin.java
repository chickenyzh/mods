package com.example.zombieevolution.mixin;

import com.example.zombieevolution.AbilityData;
import com.example.zombieevolution.EvolutionManager;
import com.example.zombieevolution.ZombieAbilityManager;
import com.example.zombieevolution.ZombieEquipmentManager;
import com.example.zombieevolution.ZombieEvolution;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Random;
import net.minecraft.class_1266;
import net.minecraft.class_1315;
import net.minecraft.class_1324;
import net.minecraft.class_1642;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3730;
import net.minecraft.class_5134;
import net.minecraft.class_5425;

@Mixin(class_1642.class)
public abstract class ZombieEntityMixin implements AbilityData {
    @Unique
    private int abilityFlags = 0;

    @Unique
    private static final Random ABILITY_RANDOM = new Random();

    @Override
    public int getAbilityFlags() {
        return abilityFlags;
    }

    @Override
    public void setAbilityFlags(int flags) {
        this.abilityFlags = flags;
    }

    @Inject(method = "finalizeSpawn", at = @At("TAIL"))
    private void onInitialize(class_5425 world, class_1266 difficulty, class_3730 reason, class_1315 spawnData, class_2487 dataTag, CallbackInfoReturnable<class_1315> cir) {
        class_1937 w = world.method_8410();
        if (w.field_9236) return;

        int day = EvolutionManager.getCurrentDay(w);

        if (reason != class_3730.field_16459 && reason != class_3730.field_16472) return;

        class_1642 self = (class_1642) (Object) this;
        self.method_7217(false);
        applyEvolution(self, world.method_8410(), day);
        ZombieEquipmentManager.applyEquipment(self, day);
        assignAbilities(day);

        ZombieEvolution.LOGGER.debug("Spawned zombie day={} reason={}", day, reason);
    }

    @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
    private void onWriteNbt(class_2487 nbt, CallbackInfo ci) {
        if (abilityFlags != 0) {
            nbt.method_10569("ZombieAbilities", abilityFlags);
        }
    }

    @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
    private void onReadNbt(class_2487 nbt, CallbackInfo ci) {
        if (nbt.method_10545("ZombieAbilities")) {
            abilityFlags = nbt.method_10550("ZombieAbilities");
        }
    }

    @Inject(method = "registerGoals", at = @At("TAIL"))
    private void onInitGoals(CallbackInfo ci) {
        class_1642 self = (class_1642) (Object) this;
        MobEntityAccessor accessor = (MobEntityAccessor) this;

        accessor.getTargetSelector().method_6277(3, new com.example.zombieevolution.goal.AggroChainGoal(self));
        accessor.getGoalSelector().method_6277(3, new com.example.zombieevolution.goal.DirectedWallBreakingGoal(self));
        accessor.getGoalSelector().method_6277(4, new com.example.zombieevolution.goal.AbilityTickGoal(self));
    }

    @Unique
    private void assignAbilities(int day) {
        double chance = ZombieAbilityManager.getAbilitySpawnChance(day);
        if (ABILITY_RANDOM.nextDouble() < chance) {
            this.abilityFlags = ZombieAbilityManager.getAbilitiesForDay(day);
        }
    }

    @Unique
    private void applyEvolution(class_1642 zombie, class_1937 world, int day) {
        if (EvolutionManager.getEvolutionStage(day) < 0) return;

        class_1324 followRangeAttr = zombie.method_5996(class_5134.field_23717);
        if (followRangeAttr != null) {
            followRangeAttr.method_6192(EvolutionManager.getFollowRangeForDay(day));
        }

        class_1324 speedAttr = zombie.method_5996(class_5134.field_23719);
        if (speedAttr != null) {
            double baseSpeed = speedAttr.method_6201();
            speedAttr.method_6192(baseSpeed * EvolutionManager.getSpeedMultiplierForDay(day));
        }

        class_1324 damageAttr = zombie.method_5996(class_5134.field_23721);
        if (damageAttr != null) {
            damageAttr.method_6192(EvolutionManager.getDamageForDay(day));
        }

        class_1324 healthAttr = zombie.method_5996(class_5134.field_23716);
        if (healthAttr != null) {
            healthAttr.method_6192(EvolutionManager.getMaxHealthForDay(day));
        }
        zombie.method_6033(EvolutionManager.getMaxHealthForDay(day));
    }
}
