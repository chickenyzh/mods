package com.example.zombieevolution.mixin;

import net.minecraft.class_1308;
import net.minecraft.class_1355;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1308.class)
public interface MobEntityAccessor {
    @Accessor("goalSelector")
    class_1355 getGoalSelector();

    @Accessor("targetSelector")
    class_1355 getTargetSelector();
}
