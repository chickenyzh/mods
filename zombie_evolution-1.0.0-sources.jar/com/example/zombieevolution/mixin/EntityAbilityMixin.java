package com.example.zombieevolution.mixin;

import com.example.zombieevolution.AbilityData;
import com.example.zombieevolution.entity.ModEntities;
import com.example.zombieevolution.entity.PhysicsLimbEntity;
import com.example.zombieevolution.item.ModItems;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1642;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public class EntityAbilityMixin {

    @Inject(method = "onClimbable", at = @At("HEAD"), cancellable = true)
    private void onClimbable(CallbackInfoReturnable<Boolean> cir) {
        if (!((Object) this instanceof class_1642)) return;
        class_1642 self = (class_1642) (Object) this;
        if (self.field_5976 && ((AbilityData) self).hasAbility(8)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "die", at = @At("HEAD"))
    private void onDeathSplit(class_1282 source, CallbackInfo ci) {
        if (!((Object) this instanceof class_1642)) return;
        class_1642 self = (class_1642) (Object) this;
        if (self.method_37908().field_9236) return;
        if (!((AbilityData) self).hasAbility(16)) return;

        class_3218 serverLevel = (class_3218) self.method_37908();
        int count = 2 + self.method_6051().method_43048(2);
        for (int i = 0; i < count; i++) {
            class_1642 baby = class_1299.field_6051.method_5883(serverLevel);
            if (baby != null) {
                baby.method_5814(
                    self.method_23317() + (self.method_6051().method_43058() - 0.5) * 2.0,
                    self.method_23318(),
                    self.method_23321() + (self.method_6051().method_43058() - 0.5) * 2.0
                );
                baby.method_7217(true);
                serverLevel.method_8649(baby);
            }
        }
        self.method_5775(new class_1799(ModItems.CORRUPTED_CORE));
    }

    @Inject(method = "die", at = @At("TAIL"))
    private void onDeathGore(class_1282 source, CallbackInfo ci) {
        if (!((Object) this instanceof class_1642)) return;
        class_1642 self = (class_1642) (Object) this;
        if (self.method_37908().field_9236) return;

        int skinIndex = Math.abs(self.method_5667().hashCode() % 15);
        class_3218 serverLevel = (class_3218) self.method_37908();

        for (PhysicsLimbEntity.LimbType type : PhysicsLimbEntity.LimbType.values()) {
            PhysicsLimbEntity limb = new PhysicsLimbEntity(ModEntities.PHYSICS_LIMB, serverLevel);
            limb.method_5814(self.method_23317(), self.method_23318() + 0.5, self.method_23321());
            limb.setLimbType(type);
            limb.setSkinIndex(skinIndex);
            limb.setRandomYaw(self.method_6051().method_43057() * 360.0f);
            limb.method_18800(
                (self.method_6051().method_43058() - 0.5) * 0.5,
                self.method_6051().method_43058() * 0.5 + 0.2,
                (self.method_6051().method_43058() - 0.5) * 0.5
            );
            serverLevel.method_8649(limb);
        }

        self.method_5650(class_1297.class_5529.field_26998);
    }
}
