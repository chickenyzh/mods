package com.example.zombieevolution.mixin;

import com.example.zombieevolution.ZombieEvolution;
import com.example.zombieevolution.client.render.feature.ZombieEyesFeatureRenderer;
import net.minecraft.class_1642;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3886;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_623;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3886.class)
public class ZombieRendererMixin {

    @Unique
    private static final class_2960[] ZOMBIE_SKINS = new class_2960[15];

    static {
        for (int i = 0; i < 15; i++) {
            ZOMBIE_SKINS[i] = ZombieEvolution.id("textures/entity/zombie/zombie_" + i + ".png");
        }
    }

    @Inject(method = "<init>(Lnet/minecraft/client/renderer/entity/EntityRendererProvider$Context;)V", at = @At("TAIL"))
    private void onConstructor(class_5617.class_5618 context, CallbackInfo ci) {
        LivingEntityRendererInvoker invoker = (LivingEntityRendererInvoker) this;
        class_3886 self = (class_3886) (Object) this;

        invoker.invokeAddFeature(new class_3887<class_1642, class_623<class_1642>>(self) {
            @Override
            public void render(class_4587 matrices, class_4597 vertexConsumers, int light, class_1642 entity, float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
                int skinIndex = Math.abs(entity.method_5667().hashCode() % 15);
                class_2960 texture = ZOMBIE_SKINS[skinIndex];
                class_4588 consumer = vertexConsumers.getBuffer(class_1921.method_23578(texture));
                this.method_17165().method_2828(matrices, consumer, light, class_4608.field_21444, 1.0f, 1.0f, 1.0f, 1.0f);
            }
        });

        invoker.invokeAddFeature(new ZombieEyesFeatureRenderer(self));
    }
}
