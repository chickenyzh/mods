package com.example.zombieevolution.mixin;

import com.example.zombieevolution.TimeSpeedManager;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3218.class)
public class ServerWorldTickMixin {
    @Unique
    private boolean timeTickGuard = false;

    @Inject(method = "tickTime", at = @At("TAIL"))
    private void onTickTime(CallbackInfo ci) {
        if (timeTickGuard) return;

        int speed = TimeSpeedManager.getTimeSpeed();
        if (speed <= 1) return;

        timeTickGuard = true;
        int extra = Math.min(speed - 1, 100);
        for (int i = 0; i < extra; i++) {
            ((ServerWorldInvoker) this).invokeTickTime();
        }
        timeTickGuard = false;
    }
}
