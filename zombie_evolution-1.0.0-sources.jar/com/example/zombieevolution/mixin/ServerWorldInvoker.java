package com.example.zombieevolution.mixin;

import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_3218.class)
public interface ServerWorldInvoker {
    @Invoker("tickTime")
    void invokeTickTime();
}
