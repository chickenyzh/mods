package com.example.zombieevolution.mixin;

import net.minecraft.class_1311;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1311.class)
public interface SpawnGroupAccessor {
    @Mutable
    @Accessor("max")
    void setCapacity(int capacity);
}
