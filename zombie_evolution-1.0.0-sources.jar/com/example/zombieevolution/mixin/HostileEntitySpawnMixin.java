package com.example.zombieevolution.mixin;

import com.example.zombieevolution.EvolutionManager;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_2338;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1588.class)
public class HostileEntitySpawnMixin {
    @Inject(method = "checkMonsterSpawnRules", at = @At("HEAD"), cancellable = true)
    private static void onCanSpawnInDark(class_1299<? extends class_1588> type, class_5425 world, class_3730 reason, class_2338 pos, class_5819 random, CallbackInfoReturnable<Boolean> cir) {
        if (type == class_1299.field_6051 || type == class_1299.field_6123) {
            int day = EvolutionManager.getCurrentDay((net.minecraft.class_1937) world);
            if (!EvolutionManager.canSpawnZombie(day)) {
                cir.setReturnValue(false);
            }
        }
    }
}
