package com.example.zombieevolution.mixin;

import com.example.zombieevolution.EvolutionManager;
import net.minecraft.class_1308;
import net.minecraft.class_1642;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
public class MobEntityMixin {
    @Inject(method = "isSunBurnTick", at = @At("HEAD"), cancellable = true)
    private void onIsAffectedByDaylight(CallbackInfoReturnable<Boolean> cir) {
        class_1308 self = (class_1308) (Object) this;
        if (!(self instanceof class_1642)) return;
        if (self.method_37908().field_9236) return;

        int day = EvolutionManager.getCurrentDay(self.method_37908());
        if (EvolutionManager.isSunImmunityActive(day)) {
            cir.setReturnValue(false);
        }
    }
}
