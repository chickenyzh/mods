package com.example.zombieevolution;

import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class ZombieAbilityManager {

    public static final int ABILITY_NONE = 0;
    public static final int ABILITY_TNT = 1;
    public static final int ABILITY_BREAK_BLOCKS = 2;
    public static final int ABILITY_BUILD = 4;
    public static final int ABILITY_CLIMB = 8;
    public static final int ABILITY_SPLIT = 16;

    public static final int TNT_UNLOCK_DAY = 10;
    public static final int BREAK_BLOCKS_UNLOCK_DAY = 20;
    public static final int BUILD_UNLOCK_DAY = 40;
    public static final int CLIMB_UNLOCK_DAY = 60;
    public static final int SPLIT_UNLOCK_DAY = 80;

    private static final class_2248[] BREAKABLE_BLOCKS = {
            class_2246.field_10566, class_2246.field_10340, class_2246.field_10474, class_2246.field_10508,
            class_2246.field_10115, class_2246.field_10445,
            class_2246.field_10161, class_2246.field_9975, class_2246.field_10148,
            class_2246.field_10334, class_2246.field_10218, class_2246.field_10075,
            class_2246.field_10431, class_2246.field_10037, class_2246.field_10511,
            class_2246.field_10306, class_2246.field_10533, class_2246.field_10010,
            class_2246.field_10126, class_2246.field_10155, class_2246.field_10307,
            class_2246.field_10303, class_2246.field_9999, class_2246.field_10178,
            class_2246.field_10563, class_2246.field_10596, class_2246.field_10440,
            class_2246.field_10392, class_2246.field_10207,
            class_2246.field_37558,
            class_2246.field_37556,
            class_2246.field_10056, class_2246.field_10065,
            class_2246.field_10416, class_2246.field_10552,
            class_2246.field_10625, class_2246.field_9990,
            class_2246.field_10269, class_2246.field_10252,
            class_2246.field_10351, class_2246.field_10119, class_2246.field_10454,
            class_2246.field_10136, class_2246.field_10131, class_2246.field_10191,
            class_2246.field_10033, class_2246.field_10285,
            class_2246.field_10620, class_2246.field_10188,
            class_2246.field_10515, class_2246.field_10114, class_2246.field_22090,
            class_2246.field_10255, class_2246.field_10102,
            class_2246.field_9979, class_2246.field_10292, class_2246.field_10361,
            class_2246.field_10467,
            class_2246.field_10534, class_2246.field_10344, class_2246.field_10117,
            class_2246.field_10518, class_2246.field_10483,
            class_2246.field_10149, class_2246.field_9973, class_2246.field_9983,
            class_2246.field_10034, class_2246.field_16328, class_2246.field_10181, class_2246.field_9980,
            class_2246.field_10336, class_2246.field_10099, class_2246.field_16541,
            class_2246.field_17350, class_2246.field_23860,
            class_2246.field_10266, class_2246.field_10364, class_2246.field_10159,
            class_2246.field_10446,
            class_2246.field_10137, class_2246.field_10576,
            class_2246.field_10104
    };

    public static double getAbilitySpawnChance(int day) {
        return Math.min(day / 10.0 * 0.1, 1.0);
    }

    public static int getAbilitiesForDay(int day) {
        int flags = 0;
        if (day >= BREAK_BLOCKS_UNLOCK_DAY) flags |= ABILITY_BREAK_BLOCKS;
        if (day >= TNT_UNLOCK_DAY) flags |= ABILITY_TNT;
        if (day >= BUILD_UNLOCK_DAY) flags |= ABILITY_BUILD;
        if (day >= CLIMB_UNLOCK_DAY) flags |= ABILITY_CLIMB;
        if (day >= SPLIT_UNLOCK_DAY) flags |= ABILITY_SPLIT;
        return flags;
    }

    public static boolean canBreakBlock(class_2338 pos, class_1937 world) {
        class_2680 state = world.method_8320(pos);
        if (state.method_26215()) return false;
        class_2248 block = state.method_26204();
        for (class_2248 b : BREAKABLE_BLOCKS) {
            if (b == block) return true;
        }
        return false;
    }
}
