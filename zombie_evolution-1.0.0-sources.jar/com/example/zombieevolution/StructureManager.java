package com.example.zombieevolution;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_2960;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import net.minecraft.class_7923;

public class StructureManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("StructureManager");

    public static String saveStructure(class_1937 level, class_2338 pos, String name) {
        class_3499 template = new class_3499();
        class_2338 startPos = pos.method_10084();
        class_2382 size = new class_2382(16, 16, 16);

        template.method_15174(level, startPos, size, false, class_2246.field_10124);

        class_2487 tag = template.method_15175(new class_2487());
        if (tag.method_33133()) {
            return null;
        }

        Path saveDir = Path.of("config", "zombie_evolution", "structures");
        try {
            Files.createDirectories(saveDir);
            Path filePath = saveDir.resolve(name + ".nbt");
            class_2507.method_30614(tag, filePath.toFile());
            LOGGER.info("Structure saved: {}", filePath.toAbsolutePath());
            return filePath.toAbsolutePath().toString();
        } catch (IOException e) {
            LOGGER.error("Failed to save structure", e);
            return null;
        }
    }

    public static boolean placeBuilding(class_1937 level, class_2338 origin, SavedBuilding building) {
        if (building.palette != null && building.blocks != null) {
            return placeBuildingFromPalette(level, origin, building);
        }
        Path filePath = Path.of("config", "zombie_evolution", "structures", building.name + ".nbt");
        if (!Files.exists(filePath)) return false;
        try {
            class_2487 tag = class_2507.method_30613(filePath.toFile());
            if (tag == null) return false;
            class_3499 template = new class_3499();
            template.method_15183(class_7923.field_41175.method_46771(), tag);
            class_3492 settings = new class_3492();
            template.method_15172((class_5425) level, origin, origin, settings, class_5819.method_43047(), 2);
            return true;
        } catch (IOException e) {
            LOGGER.error("Failed to place building: {}", building.name, e);
            return false;
        }
    }

    private static boolean placeBuildingFromPalette(class_1937 level, class_2338 origin, SavedBuilding building) {
        try {
            Gson gson = new Gson();
            Type type = new TypeToken<Map<String, String>>() {}.getType();
            Map<String, String> palette = gson.fromJson(building.palette, type);
            if (palette == null) return false;

            String[] layers = building.blocks.split("\n\n", -1);

            for (int y = 0; y < layers.length; y++) {
                String[] rows = layers[y].split("\n", -1);
                for (int z = 0; z < rows.length; z++) {
                    String row = rows[z];
                    for (int x = 0; x < row.length(); x++) {
                        String key = String.valueOf(row.charAt(x));
                        String blockId = palette.get(key);
                        if (blockId == null || blockId.isEmpty()) continue;
                        if (blockId.equals("minecraft:air")) continue;

                        class_2248 block = class_7923.field_41175.method_10223(new class_2960(blockId));
                        if (block != null && block != class_2246.field_10124) {
                            class_2338 targetPos = origin.method_10069(x, y, z);
                            if (level.method_22347(targetPos) || level.method_8320(targetPos).method_45474()) {
                                level.method_8652(targetPos, block.method_9564(), 3);
                            }
                        }
                    }
                }
            }
            return true;
        } catch (Exception e) {
            LOGGER.error("Failed to place building from palette", e);
            return false;
        }
    }

    public static class SavedBuilding {
        public final String name;
        public final int[] size;
        public String palette;
        public String blocks;
        public Map<String, String> nbt;

        public SavedBuilding(String name, int[] size) {
            this.name = name;
            this.size = size;
        }

        public SavedBuilding(String name, int[] size, String palette, String blocks, Map<String, String> nbt) {
            this.name = name;
            this.size = size;
            this.palette = palette;
            this.blocks = blocks;
            this.nbt = nbt;
        }
    }
}
