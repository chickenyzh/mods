package com.example.zombieevolution.screen;

import com.example.zombieevolution.ZombieEvolution;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;

public class DaySetterScreen extends class_437 {
	private class_342 dayField;
	private final int currentDay;

	// Settings
	private int speedMultiplier = 1;
	private boolean limbsEnabled = true;
	private boolean equipmentEnabled = true;
	private boolean buildingsEnabled = true;
	private int rarityLevel = 1;

	private static final Integer[] SPEED_OPTIONS = {1, 2, 3, 4, 5, 10};
	private static final String[] RARITY_OPTIONS = {"很低", "低", "普通", "高", "很高"};

	public DaySetterScreen(int currentDay) {
		super(class_2561.method_43471("gui.zombie_evolution.day_setter.title"));
		this.currentDay = currentDay;
	}

	@Override
	protected void method_25426() {
		int cx = this.field_22789 / 2;
		int startY = this.field_22790 / 2 - 70;

		// Day input
		this.dayField = new class_342(this.field_22793, cx - 50, startY, 100, 20, class_2561.method_43471("gui.zombie_evolution.day_setter.input"));
		this.dayField.method_1852(String.valueOf(this.currentDay));
		this.dayField.method_1890(s -> s.matches("\\d*"));
		this.method_37063(this.dayField);
		this.method_48265(this.dayField);

		// Speed cycle button
		this.method_37063(class_5676.<Integer>method_32606(i -> class_2561.method_43470("§e" + class_2561.method_43469("gui.zombie_evolution.day_setter.speed", String.valueOf(i)).getString()))
			.method_32624(SPEED_OPTIONS)
			.method_32619(1)
			.method_32617(cx - 80, startY + 30, 160, 20, class_2561.method_43469("gui.zombie_evolution.day_setter.speed", "?"),
				(btn, value) -> this.speedMultiplier = value));

		// Limbs toggle
		this.method_37063(class_5676.method_32613(this.limbsEnabled)
			.method_32617(cx - 80, startY + 55, 160, 20,
				class_2561.method_43469("gui.zombie_evolution.day_setter.limbs", ""),
				(btn, value) -> this.limbsEnabled = value));

		// Equipment toggle
		this.method_37063(class_5676.method_32613(this.equipmentEnabled)
			.method_32617(cx - 80, startY + 80, 160, 20,
				class_2561.method_43469("gui.zombie_evolution.day_setter.equipment", ""),
				(btn, value) -> this.equipmentEnabled = value));

		// Buildings toggle
		this.method_37063(class_5676.method_32613(this.buildingsEnabled)
			.method_32617(cx - 80, startY + 105, 160, 20,
				class_2561.method_43469("gui.zombie_evolution.day_setter.buildings", ""),
				(btn, value) -> this.buildingsEnabled = value));

		// Rarity cycle
		this.method_37063(class_5676.<String>method_32606(s -> class_2561.method_43470("§e" + class_2561.method_43469("gui.zombie_evolution.day_setter.rarity", s).getString()))
			.method_32624(RARITY_OPTIONS)
			.method_32619("普通")
			.method_32617(cx - 80, startY + 130, 160, 20, class_2561.method_43469("gui.zombie_evolution.day_setter.rarity", ""),
				(btn, value) -> {
					for (int i = 0; i < RARITY_OPTIONS.length; i++) {
						if (RARITY_OPTIONS[i].equals(value)) {
							this.rarityLevel = i + 1;
							break;
						}
					}
				}));

		// Confirm button
		this.method_37063(class_4185.method_46430(
			class_2561.method_43471("gui.zombie_evolution.day_setter.confirm"),
			button -> {
				try {
					int day = Integer.parseInt(this.dayField.method_1882());
					sendSettings(day);
				} catch (NumberFormatException ignored) {}
				this.method_25419();
			}).method_46434(cx - 60, startY + 160, 120, 20).method_46431());
	}

	private void sendSettings(int day) {
		class_2540 buf = PacketByteBufs.create();
		buf.writeInt(day);
		buf.writeInt(this.speedMultiplier);
		buf.writeBoolean(this.limbsEnabled);
		buf.writeFloat(1.0f); // limb weight (default)
		buf.writeBoolean(this.equipmentEnabled);
		buf.writeBoolean(this.buildingsEnabled);
		buf.writeInt(this.rarityLevel);
		ClientPlayNetworking.send(ZombieEvolution.id("set_day"), buf);
	}

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
		guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, this.field_22790 / 2 - 95, 0xFFFFFF);
		this.dayField.method_25394(guiGraphics, mouseX, mouseY, partialTick);
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
