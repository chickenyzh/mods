package com.example.zombieevolution;

import com.example.zombieevolution.StructureManager.SavedBuilding;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2507;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import net.minecraft.class_7923;

public class ModStructures {
    private static final Logger LOGGER = LoggerFactory.getLogger("ModStructures");
    private static final List<SavedBuilding> BUILDINGS = new ArrayList<>();
    private static SavedBuilding defaultShelter;

    public static void register() {
        BUILDINGS.clear();
        Path structuresDir = Path.of("config", "zombie_evolution", "structures");
        if (!Files.exists(structuresDir)) {
            try {
                Files.createDirectories(structuresDir);
            } catch (IOException e) {
                LOGGER.error("Failed to create structures directory", e);
            }
            return;
        }
        try (var stream = Files.list(structuresDir)) {
            stream.filter(p -> p.toString().endsWith(".nbt")).forEach(p -> {
                String name = p.getFileName().toString().replace(".nbt", "");
                try {
                    var tag = class_2507.method_30613(p.toFile());
                    if (tag != null && tag.method_10573("size", 9)) {
                        var sizeList = tag.method_10554("size", 3);
                        int w = sizeList.method_10600(0);
                        int h = sizeList.method_10600(1);
                        int d = sizeList.method_10600(2);
                        BUILDINGS.add(new SavedBuilding(name, new int[]{w, h, d}));
                        LOGGER.info("Loaded building: {} ({}x{}x{})", name, w, h, d);
                    }
                } catch (IOException e) {
                    LOGGER.error("Failed to load building structure: {}", p, e);
                }
            });
        } catch (IOException e) {
            LOGGER.error("Failed to list structures directory", e);
        }
        LOGGER.info("Loaded {} buildings", BUILDINGS.size());
    }

    public static SavedBuilding getRandomBuilding(class_5819 random) {
        if (BUILDINGS.isEmpty()) return null;
        return BUILDINGS.get(random.method_43048(BUILDINGS.size()));
    }

    public static SavedBuilding getShelterBuilding() {
        for (SavedBuilding b : BUILDINGS) {
            if (b.name.equals("shelter")) {
                return b;
            }
        }
        if (defaultShelter == null) {
            defaultShelter = createDefaultShelter();
        }
        return defaultShelter;
    }

    private static SavedBuilding createDefaultShelter() {
        String palette = "{\"#\":\"minecraft:stone\",\".\":\"minecraft:air\",\"S\":\"minecraft:sea_lantern\",\"C\":\"minecraft:chest\"}";

        String blocks =
                "#########\n" + "#########\n" + "#########\n" + "#########\n" + "#########\n" + "#########\n" + "#########\n" +
                "\n" +
                "#.......#\n" + "#.......#\n" + "#..C....#\n" + "#...S...#\n" + "#..C....#\n" + "#.......#\n" + "#.......#\n" +
                "\n" +
                "#.......#\n" + "#.......#\n" + "#.......#\n" + "#.......#\n" + "#.......#\n" + "#.......#\n" + "#.......#\n" +
                "\n" +
                "#.......#\n" + "#.......#\n" + "#.......#\n" + "#.......#\n" + "#.......#\n" + "#.......#\n" + "#.......#\n" +
                "\n" +
                "#########\n" + "#########\n" + "#########\n" + "#########\n" + "#########\n" + "#########\n" + "#########";

        Map<String, String> nbt = new HashMap<>();
        nbt.put("2,1,2", "");
        nbt.put("2,1,4", "");

        LOGGER.info("Using default built-in shelter");
        return new SavedBuilding("shelter", new int[]{9, 5, 7}, palette, blocks, nbt);
    }

    public static SavedBuilding placeRandomBuilding(class_1936 level, class_2338 pos, class_5819 random) {
        if (BUILDINGS.isEmpty()) return null;
        SavedBuilding building = BUILDINGS.get(random.method_43048(BUILDINGS.size()));
        Path filePath = Path.of("config", "zombie_evolution", "structures", building.name + ".nbt");
        if (!Files.exists(filePath)) return null;

        try {
            var tag = class_2507.method_30613(filePath.toFile());
            if (tag == null) return null;
            var template = new class_3499();
            template.method_15183(class_7923.field_41175.method_46771(), tag);
            var placeSettings = new class_3492();
            template.method_15172((class_5425) level, pos, pos, placeSettings, random, 2);
            return building;
        } catch (IOException e) {
            LOGGER.error("Failed to place building: {}", building.name, e);
            return null;
        }
    }
}
