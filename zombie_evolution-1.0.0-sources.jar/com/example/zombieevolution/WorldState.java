package com.example.zombieevolution;

import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_26;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

public class WorldState extends class_18 {
    private boolean shelterPlaced;

    public WorldState() {
        this.shelterPlaced = false;
    }

    @Override
    public class_2487 method_75(class_2487 nbt) {
        nbt.method_10556("ShelterPlaced", this.shelterPlaced);
        return nbt;
    }

    public static WorldState fromNbt(class_2487 nbt) {
        WorldState state = new WorldState();
        state.shelterPlaced = nbt.method_10577("ShelterPlaced");
        return state;
    }

    public boolean isShelterPlaced() {
        return shelterPlaced;
    }

    public void setShelterPlaced(boolean v) {
        this.shelterPlaced = v;
        method_80();
    }

    public static WorldState get(MinecraftServer server) {
        if (server == null) return null;
        class_3218 overworld = server.method_30002();
        if (overworld == null) return null;
        class_26 mgr = overworld.method_17983();
        return mgr.method_17924(WorldState::fromNbt, WorldState::new, "zombie_evolution");
    }
}
