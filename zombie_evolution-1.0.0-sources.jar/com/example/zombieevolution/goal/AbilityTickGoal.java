package com.example.zombieevolution.goal;

import com.example.zombieevolution.AbilityData;
import com.example.zombieevolution.mixin.LivingEntityInvoker;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;

public class AbilityTickGoal extends class_1352 {

    private final class_1642 zombie;
    private int tickCounter;

    public AbilityTickGoal(class_1642 zombie) {
        this.zombie = zombie;
    }

    @Override
    public boolean method_6264() {
        return this.zombie instanceof AbilityData data && data.getAbilityFlags() != 0;
    }

    @Override
    public boolean method_6266() {
        return method_6264();
    }

    @Override
    public void method_6268() {
        class_1937 world = this.zombie.method_37908();
        if (world.field_9236) return;

        AbilityData data = (AbilityData) this.zombie;
        int flags = data.getAbilityFlags();
        if (flags == 0) return;

        this.tickCounter++;
        class_1309 target = this.zombie.method_5968();

        // TNT ability (flag 1)
        if (data.hasAbility(1) && target instanceof class_1657) {
            if (this.zombie.method_5739(target) < 8.0f
                    && this.tickCounter % 10 == 0
                    && world.field_9229.method_43057() < 0.4f) {

                var tnt = new net.minecraft.class_1541(
                        world,
                        this.zombie.method_23317(),
                        this.zombie.method_23318(),
                        this.zombie.method_23321(),
                        null
                );
                tnt.method_6967(30);
                world.method_8649(tnt);
            }
        }

        // Builder ability (flag 4)
        if (data.hasAbility(4) && target != null) {
            if (target.method_23318() > this.zombie.method_23318() + 1
                    && this.tickCounter % 5 == 0
                    && this.zombie.method_24828()
                    && world.field_9229.method_43057() < 0.25f) {

                class_2338 feet = this.zombie.method_24515();
                if (world.method_22347(feet) && countDirtBelow(world, feet) < 3) {
                    ((LivingEntityInvoker) this.zombie).invokeJump();
                    world.method_8652(feet, class_2246.field_10566.method_9564(), 3);
                }
            }
        }
    }

    private static int countDirtBelow(class_1937 world, class_2338 pos) {
        int count = 0;
        for (int i = 1; i <= 8; i++) {
            if (world.method_8320(pos.method_10087(i)).method_27852(class_2246.field_10566)) {
                count++;
            } else {
                break;
            }
        }
        return count;
    }
}
