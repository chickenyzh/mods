package com.example.zombieevolution.goal;

import com.example.zombieevolution.AbilityData;
import com.example.zombieevolution.ZombieAbilityManager;
import java.util.EnumSet;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_1642;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public class DirectedWallBreakingGoal extends class_1352 {

    private static final int CHECK_INTERVAL = 10;
    private static final double BREAK_DISTANCE_SQ = 6.25;
    private static final double MAX_SEARCH_DISTANCE = 30.0;

    private final class_1642 zombie;
    private class_2338 targetBlock;
    private int cooldown;

    public DirectedWallBreakingGoal(class_1642 zombie) {
        this.zombie = zombie;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        class_1309 target = null;
        if (this.zombie instanceof AbilityData data) {
            if (!data.hasAbility(2)) return false;
        } else {
            return false;
        }

        target = this.zombie.method_5968();
        if (target == null) return false;

        if (this.zombie.method_5858(target) < 12.25) return false;

        if (--this.cooldown > 0) return false;
        this.cooldown = CHECK_INTERVAL;

        this.targetBlock = findBlockInPath();
        return this.targetBlock != null;
    }

    @Override
    public boolean method_6266() {
        if (this.targetBlock == null) return false;
        if (this.zombie.method_5968() == null) return false;
        class_1937 level = this.zombie.method_37908();
        if (level.method_22347(this.targetBlock)) return false;
        return ZombieAbilityManager.canBreakBlock(this.targetBlock, level);
    }

    @Override
    public void method_6269() {
        if (this.targetBlock != null) {
            navigateToBlock();
        }
    }

    @Override
    public void method_6270() {
        this.targetBlock = null;
        this.zombie.method_5942().method_6340();
    }

    @Override
    public void method_6268() {
        if (this.targetBlock == null) return;

        class_243 center = class_243.method_24953(this.targetBlock);
        if (this.zombie.method_5707(center) <= BREAK_DISTANCE_SQ) {
            this.zombie.method_37908().method_22352(this.targetBlock, true);
            this.targetBlock = null;
        } else if (this.zombie.method_5942().method_6357()) {
            navigateToBlock();
        }
    }

    private void navigateToBlock() {
        this.zombie.method_5942().method_6337(
                this.targetBlock.method_10263() + 0.5,
                this.targetBlock.method_10264(),
                this.targetBlock.method_10260() + 0.5,
                1.0
        );
    }

    private class_2338 findBlockInPath() {
        class_1309 target = this.zombie.method_5968();
        if (target == null) return null;

        class_1937 world = this.zombie.method_37908();
        class_243 start = this.zombie.method_33571();
        class_243 end = target.method_5829().method_1005();
        class_243 diff = end.method_1020(start);
        double distance = diff.method_1033();

        if (distance > MAX_SEARCH_DISTANCE || distance < 1.0) return null;

        class_243 step = diff.method_1029();
        class_2338 lastPos = null;

        for (double d = 0; d < distance; d += 1.0) {
            class_243 point = start.method_1019(step.method_1021(d));
            class_2338 pos = class_2338.method_49638(point);

            if (pos.equals(lastPos)) continue;
            lastPos = pos;

            if (world.method_22347(pos)) continue;

            if (ZombieAbilityManager.canBreakBlock(pos, world)) {
                return pos;
            }

            class_2680 state = world.method_8320(pos);
            if (state.method_26216(world, pos)) break;
        }

        return null;
    }
}
