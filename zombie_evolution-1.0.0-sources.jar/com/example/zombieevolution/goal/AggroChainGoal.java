package com.example.zombieevolution.goal;

import com.example.zombieevolution.AbilityData;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1405;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_238;

public class AggroChainGoal extends class_1405 {

    private static final double CHAIN_RANGE = 20.0;
    private static final int SCAN_INTERVAL = 10;

    private final class_1642 zombie;
    private int cooldown;
    private class_1309 chainTarget;

    public AggroChainGoal(class_1642 zombie) {
        super(zombie, false);
        this.zombie = zombie;
    }

    @Override
    public boolean method_6264() {
        if (!(this.zombie instanceof AbilityData data)) return false;
        if (data.getAbilityFlags() == 0) return false;

        if (this.zombie.method_5968() != null) return false;

        if (--this.cooldown > 0) return false;
        this.cooldown = SCAN_INTERVAL;

        this.chainTarget = findSharedTarget();
        return this.chainTarget != null;
    }

    @Override
    public void method_6269() {
        if (this.chainTarget != null) {
            this.zombie.method_5980(this.chainTarget);
        }
    }

    @Override
    public void method_6270() {
        this.chainTarget = null;
    }

    private class_1309 findSharedTarget() {
        class_238 box = this.zombie.method_5829().method_1014(CHAIN_RANGE);
        List<class_1642> list = this.zombie.method_37908().method_8390(
                class_1642.class, box, this::isValidChainSource
        );

        for (class_1642 other : list) {
            class_1309 t = other.method_5968();
            if (t instanceof class_1657 player) {
                if (player.method_5805() && !player.method_7337() && !player.method_7325()) {
                    return player;
                }
            }
        }
        return null;
    }

    private boolean isValidChainSource(class_1642 other) {
        if (other == this.zombie) return false;

        if (other instanceof AbilityData data) {
            if (data.getAbilityFlags() == 0) return false;
        } else {
            return false;
        }

        class_1309 t = other.method_5968();
        return t != null && t.method_5805();
    }
}
