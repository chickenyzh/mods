package com.example.zombieevolution;

import net.minecraft.class_1304;
import net.minecraft.class_1642;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1893;

public class ZombieEquipmentManager {

    public static int getEquipmentTier(int day) {
        if (day >= 90) return 3;
        if (day >= 70) return 2;
        if (day >= 50) return 1;
        if (day >= 30) return 0;
        return -1;
    }

    public static void applyEquipment(class_1642 zombie, int day) {
        int tier = getEquipmentTier(day);
        switch (tier) {
            case 0 -> equipIron(zombie);
            case 1 -> equipDiamond(zombie);
            case 2 -> equipEnchantedDiamond(zombie);
            case 3 -> equipNetherite(zombie);
        }
    }

    private static void equipIron(class_1642 zombie) {
        zombie.method_5673(class_1304.field_6169, new class_1799(class_1802.field_8743));
        zombie.method_5673(class_1304.field_6174, new class_1799(class_1802.field_8523));
        zombie.method_5673(class_1304.field_6172, new class_1799(class_1802.field_8396));
        zombie.method_5673(class_1304.field_6166, new class_1799(class_1802.field_8660));
        zombie.method_5673(class_1304.field_6173, new class_1799(class_1802.field_8371));
    }

    private static void equipDiamond(class_1642 zombie) {
        zombie.method_5673(class_1304.field_6169, new class_1799(class_1802.field_8805));
        zombie.method_5673(class_1304.field_6174, new class_1799(class_1802.field_8058));
        zombie.method_5673(class_1304.field_6172, new class_1799(class_1802.field_8348));
        zombie.method_5673(class_1304.field_6166, new class_1799(class_1802.field_8285));
        zombie.method_5673(class_1304.field_6173, new class_1799(class_1802.field_8802));
    }

    private static void equipEnchantedDiamond(class_1642 zombie) {
        zombie.method_5673(class_1304.field_6169, makeHelmet(class_1802.field_8805, 4, 3, 2, 2, 1));
        zombie.method_5673(class_1304.field_6174, makeArmor(class_1802.field_8058, 4, 3, 2));
        zombie.method_5673(class_1304.field_6172, makeArmor(class_1802.field_8348, 4, 3, 2));
        zombie.method_5673(class_1304.field_6166, makeBoots(class_1802.field_8285, 4, 3, 2, 3));
        zombie.method_5673(class_1304.field_6173, makeSword(class_1802.field_8802, 4, 2, 2));
    }

    private static void equipNetherite(class_1642 zombie) {
        zombie.method_5673(class_1304.field_6169, makeHelmet(class_1802.field_22027, 4, 3, 3, 3, 1));
        zombie.method_5673(class_1304.field_6174, makeArmor(class_1802.field_22028, 4, 3, 3));
        zombie.method_5673(class_1304.field_6172, makeArmor(class_1802.field_22029, 4, 3, 3));
        zombie.method_5673(class_1304.field_6166, makeBoots(class_1802.field_22030, 4, 3, 3, 4));
        zombie.method_5673(class_1304.field_6173, makeSword(class_1802.field_22022, 5, 2, 2));
    }

    private static class_1799 makeArmor(class_1792 item, int prot, int unbreaking, int thorns) {
        class_1799 stack = new class_1799(item);
        if (prot > 0) stack.method_7978(class_1893.field_9111, prot);
        if (unbreaking > 0) stack.method_7978(class_1893.field_9119, unbreaking);
        if (thorns > 0) stack.method_7978(class_1893.field_9097, thorns);
        return stack;
    }

    private static class_1799 makeHelmet(class_1792 item, int prot, int unbreaking, int thorns, int respiration, int aquaAffinity) {
        class_1799 stack = makeArmor(item, prot, unbreaking, thorns);
        if (respiration > 0) stack.method_7978(class_1893.field_9127, respiration);
        if (aquaAffinity > 0) stack.method_7978(class_1893.field_9105, aquaAffinity);
        return stack;
    }

    private static class_1799 makeBoots(class_1792 item, int prot, int unbreaking, int thorns, int featherFalling) {
        class_1799 stack = makeArmor(item, prot, unbreaking, thorns);
        if (featherFalling > 0) stack.method_7978(class_1893.field_9129, featherFalling);
        return stack;
    }

    private static class_1799 makeSword(class_1792 item, int sharpness, int knockback, int fireAspect) {
        class_1799 stack = new class_1799(item);
        if (sharpness > 0) stack.method_7978(class_1893.field_9118, sharpness);
        if (knockback > 0) stack.method_7978(class_1893.field_9121, knockback);
        if (fireAspect > 0) stack.method_7978(class_1893.field_9124, fireAspect);
        return stack;
    }
}
