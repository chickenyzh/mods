package com.example.zombieevolution;

import com.example.zombieevolution.StructureManager.SavedBuilding;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2586;
import net.minecraft.class_2621;
import net.minecraft.class_5819;

public class StructureLoot {

    public enum LootTier {
        BASIC, GOOD, RARE, EPIC
    }

    private static final String[] WEAPON_TYPES = {
            "minecraft:iron_sword", "minecraft:diamond_sword",
            "minecraft:bow", "minecraft:crossbow"
    };
    private static final String[] TOOL_TYPES = {
            "minecraft:iron_pickaxe", "minecraft:diamond_pickaxe",
            "minecraft:iron_axe", "minecraft:diamond_axe"
    };
    private static final String[] ARMOR_TYPES = {
            "minecraft:iron_chestplate", "minecraft:diamond_chestplate",
            "minecraft:iron_boots", "minecraft:diamond_boots"
    };
    private static final String[] CORRUPTED_ARMOR = {
            "zombie_evolution:corrupted_crystal_helmet",
            "zombie_evolution:corrupted_crystal_chestplate",
            "zombie_evolution:corrupted_crystal_leggings",
            "zombie_evolution:corrupted_crystal_boots"
    };

    public static void fillChests(class_1937 world, class_2338 origin, SavedBuilding building, class_5819 random) {
        if (building.nbt == null) return;
        for (String key : building.nbt.keySet()) {
            String[] parts = key.split(",");
            if (parts.length != 3) continue;
            try {
                int x = Integer.parseInt(parts[0].trim());
                int y = Integer.parseInt(parts[1].trim());
                int z = Integer.parseInt(parts[2].trim());
                class_2338 chestPos = origin.method_10069(x, y, z);
                class_2586 be = world.method_8321(chestPos);
                if (be instanceof class_2621 chest) {
                    LootTier tier = getTierForPosition(x, y, z, random);
                    fillChest(chest, random, tier);
                }
            } catch (NumberFormatException ignored) {
            }
        }
    }

    private static LootTier getTierForPosition(int x, int y, int z, class_5819 random) {
        float roll = random.method_43057();
        if (roll < 0.4f) return LootTier.BASIC;
        if (roll < 0.65f) return LootTier.GOOD;
        if (roll < 0.85f) return LootTier.RARE;
        return LootTier.EPIC;
    }

    private static void fillChest(class_2621 chest, class_5819 random, LootTier tier) {
        class_2499 items = new class_2499();
        int slot = 0;

        slot = addGuaranteedItems(items, random, slot);
        slot = switch (tier) {
            case BASIC -> addBasicLoot(items, random, slot);
            case GOOD -> addGoodLoot(items, random, slot);
            case RARE -> addRareLoot(items, random, slot);
            case EPIC -> addEpicLoot(items, random, slot);
        };

        class_2487 nbt = new class_2487();
        nbt.method_10566("Items", items);
        chest.method_11014(nbt);
        chest.method_5431();
    }

    private static int addGuaranteedItems(class_2499 items, class_5819 random, int slot) {
        slot = addItem(items, item("minecraft:baked_potato", 1 + random.method_43048(3)), slot);
        slot = addItem(items, item("minecraft:torch", 2 + random.method_43048(4)), slot);
        if (random.method_43057() < 0.5f) {
            slot = addItem(items, item("minecraft:rotten_flesh", 1 + random.method_43048(3)), slot);
        }
        return slot;
    }

    private static int addBasicLoot(class_2499 items, class_5819 random, int slot) {
        slot = addItem(items, item("minecraft:bread", 2 + random.method_43048(4)), slot);
        if (random.method_43057() < 0.4f)
            slot = addItem(items, item("minecraft:iron_nugget", 3 + random.method_43048(6)), slot);
        if (random.method_43057() < 0.3f)
            slot = addItem(items, item("minecraft:arrow", 2 + random.method_43048(5)), slot);
        if (random.method_43057() < 0.3f)
            slot = addItem(items, item("minecraft:stick", 2 + random.method_43048(4)), slot);
        if (random.method_43057() < 0.2f)
            slot = addItem(items, item("minecraft:string", 1 + random.method_43048(3)), slot);
        if (random.method_43057() < 0.15f)
            slot = addItem(items, item("minecraft:iron_ingot", 1), slot);
        return slot;
    }

    private static int addGoodLoot(class_2499 items, class_5819 random, int slot) {
        slot = addItem(items, item("minecraft:iron_ingot", 2 + random.method_43048(4)), slot);
        slot = addItem(items, item("minecraft:bread", 3 + random.method_43048(5)), slot);
        if (random.method_43057() < 0.3f)
            slot = addItem(items, item("minecraft:golden_apple", 1), slot);
        if (random.method_43057() < 0.3f)
            slot = addItem(items, enchantedItem("minecraft:iron_sword", "minecraft:sharpness", 1 + random.method_43048(2)), slot);
        if (random.method_43057() < 0.2f)
            slot = addItem(items, item("minecraft:diamond", 1), slot);
        if (random.method_43057() < 0.25f)
            slot = addItem(items, item("minecraft:emerald", 1 + random.method_43048(3)), slot);
        if (random.method_43057() < 0.15f)
            slot = addItem(items, item("minecraft:cobweb", 1 + random.method_43048(2)), slot);
        if (random.method_43057() < 0.1f)
            slot = addItem(items, item("zombie_evolution:corrupted_core", 1), slot);
        return slot;
    }

    private static int addRareLoot(class_2499 items, class_5819 random, int slot) {
        slot = addItem(items, item("minecraft:diamond", 1 + random.method_43048(2)), slot);
        slot = addItem(items, item("minecraft:golden_apple", 1), slot);

        float roll = random.method_43057();
        if (roll < 0.4f) {
            slot = addItem(items, enchantedItem(pick(random, WEAPON_TYPES), "minecraft:sharpness", 3), slot);
        } else if (roll < 0.7f) {
            slot = addItem(items, enchantedItem(pick(random, TOOL_TYPES), "minecraft:efficiency", 3), slot);
        } else {
            slot = addItem(items, enchantedItem(pick(random, ARMOR_TYPES), "minecraft:protection", 3), slot);
        }

        if (random.method_43057() < 0.25f)
            slot = addItem(items, item("minecraft:enchanted_golden_apple", 1), slot);
        if (random.method_43057() < 0.2f)
            slot = addItem(items, item("minecraft:ender_pearl", 1), slot);
        if (random.method_43057() < 0.2f)
            slot = addItem(items, item("zombie_evolution:corrupted_core", 1), slot);
        if (random.method_43057() < 0.15f)
            slot = addItem(items, item("zombie_evolution:corrupted_crystal_ingot", 1), slot);
        return slot;
    }

    private static int addEpicLoot(class_2499 items, class_5819 random, int slot) {
        slot = addItem(items, item("minecraft:diamond", 2 + random.method_43048(3)), slot);
        slot = addItem(items, item("minecraft:golden_apple", 1 + random.method_43048(2)), slot);

        if (random.method_43057() < 0.5f) {
            slot = addItem(items, enchantedItem(
                    "minecraft:diamond_sword",
                    new String[]{"minecraft:sharpness", "minecraft:unbreaking"},
                    new int[]{3, 2}
            ), slot);
        } else {
            slot = addItem(items, enchantedItem(
                    "minecraft:diamond_pickaxe",
                    new String[]{"minecraft:efficiency", "minecraft:unbreaking"},
                    new int[]{3, 2}
            ), slot);
        }

        if (random.method_43057() < 0.33f)
            slot = addItem(items, enchantedItem(
                    "minecraft:diamond_chestplate",
                    new String[]{"minecraft:protection", "minecraft:unbreaking"},
                    new int[]{3, 2}
            ), slot);
        if (random.method_43057() < 0.3f)
            slot = addItem(items, item("minecraft:enchanted_golden_apple", 1), slot);
        if (random.method_43057() < 0.3f)
            slot = addItem(items, item("minecraft:arrow", 8 + random.method_43048(8)), slot);
        slot = addItem(items, item("zombie_evolution:corrupted_core", 1 + random.method_43048(2)), slot);
        if (random.method_43057() < 0.3f)
            slot = addItem(items, item("zombie_evolution:corrupted_crystal_ingot", 1), slot);
        if (random.method_43057() < 0.3f)
            slot = addItem(items, item("zombie_evolution:corrupted_crystal_sword", 1), slot);
        if (random.method_43057() < 0.3f)
            slot = addItem(items, item("zombie_evolution:corrupted_crystal_pickaxe", 1), slot);
        if (random.method_43057() < 0.2f)
            slot = addItem(items, item(pick(random, CORRUPTED_ARMOR), 1), slot);
        if (random.method_43057() < 0.15f)
            slot = addItem(items, item("minecraft:experience_bottle", 4 + random.method_43048(8)), slot);
        return slot;
    }

    private static class_2487 item(String id, int count) {
        class_2487 tag = new class_2487();
        tag.method_10582("id", id);
        tag.method_10567("Count", (byte) count);
        return tag;
    }

    private static class_2487 enchantedItem(String id, String enchId, int level) {
        class_2487 tag = item(id, 1);
        class_2487 enchantTag = new class_2487();
        class_2499 enchantList = new class_2499();
        class_2487 enchant = new class_2487();
        enchant.method_10582("id", enchId);
        enchant.method_10569("lvl", level);
        enchantList.add(enchant);
        enchantTag.method_10566("Enchantments", enchantList);
        tag.method_10566("tag", enchantTag);
        return tag;
    }

    private static class_2487 enchantedItem(String id, String[] enchIds, int[] levels) {
        class_2487 tag = item(id, 1);
        class_2499 enchantList = new class_2499();
        for (int i = 0; i < enchIds.length; i++) {
            class_2487 enchant = new class_2487();
            enchant.method_10582("id", enchIds[i]);
            enchant.method_10569("lvl", levels[i]);
            enchantList.add(enchant);
        }
        class_2487 enchantTag = new class_2487();
        enchantTag.method_10566("Enchantments", enchantList);
        tag.method_10566("tag", enchantTag);
        return tag;
    }

    private static String pick(class_5819 random, String[] array) {
        return array[random.method_43048(array.length)];
    }

    private static int addItem(class_2499 items, class_2487 item, int slot) {
        item.method_10567("Slot", (byte) slot);
        items.add(item);
        return slot + 1;
    }
}
